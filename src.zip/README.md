# Tadalafarma

Sistema completo de e-commerce para farmácia desenvolvido em Spring Boot com arquitetura em camadas, gestão de produtos, pedidos, clientes e usuários do backoffice.

## 📋 Descrição

O Tadalafarma é uma aplicação web para gestão de farmácia online que permite:
- **Loja Virtual**: Catálogo de produtos, carrinho de compras e checkout completo
- **Área do Cliente**: Cadastro, login, gestão de perfil e endereços, acompanhamento de pedidos
- **Backoffice**: Gestão de produtos, pedidos, usuários (administradores e estoquistas)
- **Integração com ViaCEP**: Busca automática de endereços por CEP

## 🛠️ Stack Tecnológica

- **Java**: 17
- **Spring Boot**: 3.5.6
- **Spring Security**: Autenticação e autorização baseada em sessão
- **MongoDB**: Banco de dados NoSQL
- **Thymeleaf**: Template engine para views HTML
- **Maven**: Gerenciamento de dependências
- **JUnit 5 + Mockito**: Framework de testes

## ⚙️ Pré-requisitos

- Java 17 ou superior
- Maven 3.6+ 
- MongoDB (local ou MongoDB Atlas)
- IDE (Eclipse, IntelliJ IDEA ou VS Code)

## 🚀 Instalação e Configuração

### 1. Clone o repositório

```bash
git clone <url-do-repositorio>
cd tadalafarma-main
```

### 2. Configure o MongoDB

Edite o arquivo `src/main/resources/application.properties` e configure a URI de conexão do MongoDB:

```properties
spring.data.mongodb.uri=mongodb+srv://usuario:senha@cluster.mongodb.net/tadalafarma?retryWrites=true&w=majority
```

Ou para MongoDB local:

```properties
spring.data.mongodb.uri=mongodb://localhost:27017/tadalafarma
```

### 3. Compile o projeto

```bash
mvn clean install
```

### 4. Execute a aplicação

```bash
mvn spring-boot:run
```

Ou execute diretamente a classe `TadalafarmaApplication.java` através da sua IDE.

A aplicação estará disponível em: **http://localhost:8081**

## 👤 Credenciais Padrão

### Usuário Administrador
- **Email**: `admin@tadalafarma.com`
- **Senha**: `admin123`

### Usuário Estoquista
- **Email**: `estoquista@tadalafarma.com`
- **Senha**: `esto123`

**Nota**: Estes usuários são criados automaticamente na primeira execução através do `DataInitializer`.

## 📁 Estrutura do Projeto

```
tadalafarma-main/
├── src/
│   ├── main/
│   │   ├── java/com/tadalafarma/Tadalafarma/
│   │   │   ├── config/          # Configurações (Security, DataInitializer)
│   │   │   ├── controller/      # Controllers REST/MVC
│   │   │   ├── model/           # Entidades do domínio
│   │   │   ├── repository/      # Repositórios MongoDB
│   │   │   ├── service/         # Lógica de negócio
│   │   │   └── TadalafarmaApplication.java
│   │   └── resources/
│   │       ├── static/          # CSS, imagens
│   │       ├── templates/       # Templates Thymeleaf
│   │       └── application.properties
│   └── test/
│       └── java/com/tadalafarma/Tadalafarma/
│           ├── controller/      # Testes de controllers
│           ├── model/           # Testes de models
│           └── service/         # Testes de services
├── pom.xml
└── README.md
```

## 🔌 Principais Endpoints

### Loja (Público)
- `GET /` ou `GET /loja` - Página inicial com catálogo de produtos
- `GET /loja/produto/{id}` - Detalhes do produto
- `POST /loja/carrinho/adicionar` - Adicionar produto ao carrinho
- `GET /loja/carrinho` - Visualizar carrinho
- `POST /loja/carrinho/calcular-frete-cep` - Calcular frete por CEP

### Cliente (Autenticado)
- `GET /cadastro` - Formulário de cadastro
- `POST /cadastro` - Processar cadastro
- `GET /login` - Formulário de login
- `POST /login` - Processar login
- `GET /cliente/perfil` - Perfil do cliente
- `GET /cliente/meus-pedidos` - Lista de pedidos
- `GET /cliente/pedido/{numeroPedido}` - Detalhes do pedido
- `GET /checkout/endereco` - Escolher endereço de entrega
- `GET /checkout/pagamento` - Escolher forma de pagamento
- `GET /checkout/resumo` - Resumo do pedido
- `POST /checkout/finalizar` - Finalizar pedido

### Backoffice (Autenticado)
- `GET /backoffice/login` - Login do backoffice
- `POST /backoffice/login` - Processar login
- `GET /backoffice` - Dashboard do backoffice
- `GET /pedidos` - Listar pedidos (Estoquista)
- `GET /pedidos/{id}/editar` - Editar status do pedido
- `GET /produtos` - Listar produtos
- `GET /produtos/cadastrar` - Cadastrar produto (Administrador)
- `GET /produtos/{id}/alterar` - Alterar produto
- `GET /usuarios` - Listar usuários (Administrador)
- `GET /usuarios/cadastrar` - Cadastrar usuário (Administrador)

## 🎯 Funcionalidades Principais

### Loja
- ✅ Catálogo de produtos com imagens
- ✅ Carrinho de compras em sessão
- ✅ Cálculo de frete baseado em CEP
- ✅ Checkout completo (endereço, pagamento, resumo)

### Área do Cliente
- ✅ Cadastro com validação de CPF e email
- ✅ Login e logout
- ✅ Gestão de perfil e dados pessoais
- ✅ Múltiplos endereços de entrega
- ✅ Acompanhamento de pedidos
- ✅ Histórico de compras

### Backoffice
- ✅ Gestão de produtos (CRUD completo)
- ✅ Upload e gerenciamento de imagens de produtos
- ✅ Controle de estoque
- ✅ Gestão de pedidos e status
- ✅ Gestão de usuários (administradores e estoquistas)
- ✅ Controle de acesso por grupos/permissões

## 🧪 Testes

### Executar todos os testes

```bash
mvn test
```

### Executar testes específicos

```bash
mvn test -Dtest=PedidoServiceTest
```

### Cobertura de testes

O projeto possui testes unitários e de integração para:
- Services (PedidoService, ClienteService, ProdutoService, UsuarioService, ViaCepService)
- Controllers (BackofficeController, ClienteController, LojaController, LoginController, ProdutoController)
- Models (Pedido, Cliente, Endereco, ItemPedido, Produto, ProdutoImagem, Usuario)

Para mais detalhes sobre os testes, consulte a documentação em `docs/TESTES.md` e `docs/PLANO_TESTES.md`.

## 📚 Documentação Adicional

- [Arquitetura do Sistema](docs/ARQUITETURA.md)
- [Documentação da API](docs/API.md)
- [Guia de Desenvolvimento](docs/DESENVOLVIMENTO.md)
- [Documentação de Testes](docs/TESTES.md)
- [Plano de Testes](docs/PLANO_TESTES.md)

## 🔧 Configurações

### Porta do Servidor
Por padrão, a aplicação roda na porta **8081**. Para alterar, edite `application.properties`:

```properties
server.port=8080
```

### Upload de Arquivos
O tamanho máximo de upload é 10MB:

```properties
spring.servlet.multipart.max-file-size=10MB
spring.servlet.multipart.max-request-size=10MB
```

### Cache do Thymeleaf
Em desenvolvimento, o cache está desabilitado:

```properties
spring.thymeleaf.cache=false
```

## 📝 Status dos Pedidos

Os pedidos podem ter os seguintes status:
- `AGUARDANDO_PAGAMENTO` - Aguardando Pagamento
- `PAGAMENTO_REJEITADO` - Pagamento Rejeitado
- `PAGAMENTO_COM_SUCESSO` - Pagamento com Sucesso
- `AGUARDANDO_RETIRADA` - Aguardando Retirada
- `EM_TRANSITO` - Em Trânsito
- `ENTREGUE` - Entregue

## 👥 Grupos de Usuários

- **ADMINISTRADOR**: Acesso completo ao sistema (produtos, usuários, pedidos)
- **ESTOQUISTA**: Pode gerenciar pedidos e estoque de produtos

## 🔐 Segurança

- Autenticação baseada em sessão HTTP
- Senhas criptografadas com BCrypt
- Validação de CPF e email
- Controle de acesso por grupos de usuários
- Proteção de rotas sensíveis

## 🤝 Contribuição

1. Faça um fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/MinhaFeature`)
3. Commit suas mudanças (`git commit -m 'Adiciona MinhaFeature'`)
4. Push para a branch (`git push origin feature/MinhaFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto é um exemplo educacional de sistema de e-commerce desenvolvido para fins acadêmicos.

## 👨‍💻 Autor

Projeto desenvolvido para demonstrar conhecimento em Spring Boot, MongoDB e desenvolvimento web full-stack.

---

Para mais informações, consulte a documentação completa na pasta `docs/`.
