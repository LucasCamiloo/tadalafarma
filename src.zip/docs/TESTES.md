# Documentação de Testes - Tadalafarma

## Estratégia de Testes

O projeto Tadalafarma utiliza uma estratégia de testes em camadas, focada em garantir a qualidade e confiabilidade do código através de testes unitários e de integração.

## Framework de Testes

### Tecnologias Utilizadas

- **JUnit 5**: Framework de testes unitários
- **Mockito**: Framework de mocks para isolamento de dependências
- **Spring Boot Test**: Suporte para testes de integração
- **MockMvc**: Testes de controllers MVC

### Dependências

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
</dependency>
```

A dependência `spring-boot-starter-test` já inclui:
- JUnit 5
- Mockito
- AssertJ
- Hamcrest
- Spring Boot Test

## Tipos de Testes

### 1. Testes Unitários

**Objetivo**: Testar unidades isoladas de código (métodos, classes).

**Características**:
- Testam lógica de negócio isoladamente
- Usam mocks para dependências externas
- Execução rápida
- Não requerem contexto Spring completo

**Exemplo**: Testes de Services com repositories mockados

### 2. Testes de Integração

**Objetivo**: Testar integração entre componentes.

**Características**:
- Testam interação entre camadas
- Usam contexto Spring
- Podem acessar banco de dados de teste
- Execução mais lenta

**Exemplo**: Testes de Controllers com MockMvc

### 3. Testes de Modelos

**Objetivo**: Testar lógica e métodos auxiliares das entidades.

**Características**:
- Testam métodos de negócio dos models
- Validações e transformações
- Métodos auxiliares

**Exemplo**: Testes de validação e formatação

## Estrutura de Testes

### Organização de Arquivos

```
src/test/java/com/tadalafarma/Tadalafarma/
├── controller/
│   ├── BackofficeControllerTest.java
│   ├── ClienteControllerTest.java
│   ├── LojaControllerTest.java
│   ├── LoginControllerTest.java       # A implementar
│   └── ProdutoControllerTest.java     # A implementar
├── model/
│   ├── PedidoTest.java
│   ├── ClienteTest.java               # A implementar
│   ├── EnderecoTest.java              # A implementar
│   ├── ItemPedidoTest.java            # A implementar
│   ├── ProdutoTest.java               # A implementar
│   ├── ProdutoImagemTest.java         # A implementar
│   └── UsuarioTest.java               # A implementar
├── service/
│   ├── PedidoServiceTest.java
│   ├── ClienteServiceTest.java        # A implementar
│   ├── ProdutoServiceTest.java        # A implementar
│   ├── UsuarioServiceTest.java        # A implementar
│   └── ViaCepServiceTest.java         # A implementar
└── TadalafarmaApplicationTests.java
```

## Cobertura Atual

### Testes Implementados

#### Services
- ✅ **PedidoServiceTest** - Cobertura completa
  - Buscar todos os pedidos
  - Atualizar status do pedido
  - Validações de status

#### Controllers
- ✅ **BackofficeControllerTest** - Testes de endpoints de pedidos
  - Listar pedidos
  - Editar pedido
  - Atualizar status

- ✅ **ClienteControllerTest** - Testes de detalhes de pedido
  - Visualizar detalhes do pedido
  - Verificações de autenticação e propriedade

- ✅ **LojaControllerTest** - Testes de cálculo de frete
  - Calcular frete por CEP
  - Validação de CEP

#### Models
- ✅ **PedidoTest** - Testes do modelo Pedido
  - Adicionar itens
  - Status e formatação
  - Dados do cartão

#### Application Tests
- ✅ **TadalafarmaApplicationTests** - Teste de contexto Spring Boot

### Componentes Não Testados

#### Services
- ❌ **ClienteService** - Validações, autenticação, CRUD
- ❌ **ProdutoService** - CRUD, gerenciamento de imagens
- ❌ **UsuarioService** - Validações, autenticação, CRUD
- ❌ **ViaCepService** - Integração com API ViaCEP

#### Controllers
- ❌ **LoginController** - Login/logout do backoffice
- ❌ **ProdutoController** - CRUD completo de produtos
- ❌ **ClienteController** - Outras funcionalidades (checkout, perfil)
- ❌ **LojaController** - Outras funcionalidades (carrinho completo)

#### Models
- ❌ **Cliente** - Métodos de negócio, validações
- ❌ **Endereco** - Validações, formatação
- ❌ **ItemPedido** - Lógica de negócio
- ❌ **Produto** - Métodos de negócio
- ❌ **ProdutoImagem** - Lógica de negócio
- ❌ **Usuario** - Métodos de negócio, grupos

## Padrões de Teste

### Padrão AAA (Arrange-Act-Assert)

```java
@Test
void testNomeDoMetodo_Cenario_ResultadoEsperado() {
    // Arrange - Preparar dados e mocks
    String cpf = "11144477735";
    when(repository.existsByCpf(cpf)).thenReturn(false);
    
    // Act - Executar ação
    boolean resultado = service.cpfJaExiste(cpf);
    
    // Assert - Verificar resultado
    assertFalse(resultado);
    verify(repository, times(1)).existsByCpf(cpf);
}
```

### Nomenclatura de Testes

**Padrão**: `test[NomeDoMetodo]_[Cenario]_[ResultadoEsperado]`

**Exemplos**:
```java
testValidarCpf_ComCpfValido_DeveRetornarTrue()
testAutenticar_ComCredenciaisInvalidas_DeveRetornarNull()
testCadastrarCliente_ComDadosValidos_DeveRetornarSucesso()
```

### Anotações Comuns

```java
@ExtendWith(MockitoExtension.class)  // Para testes com Mockito
@WebMvcTest(Controller.class)        // Para testes de controllers
@SpringBootTest                       // Para testes de integração
@Mock                                 // Mock de dependência
@MockBean                             // MockBean para contexto Spring
@InjectMocks                          // Injetar mocks
@BeforeEach                           // Setup antes de cada teste
```

## Executar Testes

### Via Maven

```bash
# Executar todos os testes
mvn test

# Executar teste específico
mvn test -Dtest=ClienteServiceTest

# Executar testes de um pacote
mvn test -Dtest=com.tadalafarma.Tadalafarma.service.*

# Executar com cobertura (requer plugin JaCoCo)
mvn clean test jacoco:report
```

### Via IDE

**IntelliJ IDEA**:
- Clicar com botão direito na classe de teste
- Selecionar "Run 'NomeDoTeste'"
- Ou usar atalho: `Ctrl+Shift+F10`

**Eclipse**:
- Clicar com botão direito na classe de teste
- Selecionar "Run As" → "JUnit Test"

### Executar Teste Específico

```java
// Executar apenas um teste específico
@Test
void testNomeDoTeste() {
    // ...
}
```

## Mocks e Fixtures

### Criar Mocks

```java
@Mock
private ClienteRepository clienteRepository;

@InjectMocks
private ClienteService clienteService;
```

### Configurar Mocks

```java
when(clienteRepository.findByEmail("email@teste.com"))
    .thenReturn(Optional.of(cliente));

when(clienteRepository.save(any(Cliente.class)))
    .thenReturn(cliente);
```

### Verificar Chamadas

```java
verify(clienteRepository, times(1)).findByEmail(email);
verify(clienteRepository, never()).save(any());
```

### Fixtures (Dados de Teste)

```java
@BeforeEach
void setUp() {
    cliente = new Cliente();
    cliente.setId("cliente1");
    cliente.setNome("Cliente Teste");
    cliente.setEmail("cliente@teste.com");
    // ...
}
```

## Testes de Controllers com MockMvc

### Configuração

```java
@WebMvcTest(ClienteController.class)
@AutoConfigureMockMvc(addFilters = false)
class ClienteControllerTest {
    
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    private ClienteService clienteService;
}
```

### Exemplo de Teste

```java
@Test
void testDetalhesPedido_QuandoPedidoExiste_DeveRetornarDetalhes() throws Exception {
    // Arrange
    Long numeroPedido = 1L;
    when(pedidoService.buscarPedidoPorNumero(numeroPedido))
        .thenReturn(Optional.of(pedido));
    
    // Act & Assert
    mockMvc.perform(get("/cliente/pedido/{numeroPedido}", numeroPedido)
            .sessionAttr("clienteLogado", cliente))
            .andExpect(status().isOk())
            .andExpect(view().name("cliente/detalhes-pedido"))
            .andExpect(model().attributeExists("pedido"));
    
    verify(pedidoService, times(1)).buscarPedidoPorNumero(numeroPedido);
}
```

## Testes de Services

### Estrutura Base

```java
@ExtendWith(MockitoExtension.class)
class ClienteServiceTest {
    
    @Mock
    private ClienteRepository clienteRepository;
    
    @Mock
    private ViaCepService viaCepService;
    
    @InjectMocks
    private ClienteService clienteService;
    
    private Cliente cliente;
    
    @BeforeEach
    void setUp() {
        cliente = new Cliente();
        // ... configurar cliente
    }
}
```

### Exemplo de Teste

```java
@Test
void testValidarCpf_ComCpfValido_DeveRetornarTrue() {
    // Arrange
    String cpfValido = "11144477735";
    
    // Act
    boolean resultado = clienteService.validarCpf(cpfValido);
    
    // Assert
    assertTrue(resultado);
}
```

## Métricas de Cobertura

### Cobertura Atual (Estimada)

- **Services**: ~20% (apenas PedidoService)
- **Controllers**: ~30% (BackofficeController, ClienteController parcial, LojaController parcial)
- **Models**: ~15% (apenas Pedido)

### Meta de Cobertura

- **Services**: > 80%
- **Controllers**: > 70%
- **Models**: > 70%
- **Geral**: > 70%

### Ferramentas de Cobertura

#### JaCoCo (Recomendado)

Adicionar ao `pom.xml`:

```xml
<plugin>
    <groupId>org.jacoco</groupId>
    <artifactId>jacoco-maven-plugin</artifactId>
    <version>0.8.8</version>
    <executions>
        <execution>
            <goals>
                <goal>prepare-agent</goal>
            </goals>
        </execution>
        <execution>
            <id>report</id>
            <phase>test</phase>
            <goals>
                <goal>report</goal>
            </goals>
        </execution>
    </executions>
</plugin>
```

Executar:

```bash
mvn clean test jacoco:report
```

Relatório em: `target/site/jacoco/index.html`

## Casos de Teste Comuns

### Validações

```java
// Testar validação bem-sucedida
@Test
void testValidarEmail_ComEmailValido_DeveRetornarTrue() {
    assertTrue(service.validarEmail("teste@exemplo.com"));
}

// Testar validação com erro
@Test
void testValidarEmail_ComEmailInvalido_DeveRetornarFalse() {
    assertFalse(service.validarEmail("email-invalido"));
}

// Testar casos de borda
@Test
void testValidarEmail_ComEmailNull_DeveRetornarFalse() {
    assertFalse(service.validarEmail(null));
}
```

### Autenticação

```java
@Test
void testAutenticar_ComCredenciaisValidas_DeveRetornarCliente() {
    when(repository.findByEmail(email)).thenReturn(Optional.of(cliente));
    when(passwordEncoder.matches(senha, cliente.getSenha())).thenReturn(true);
    
    Cliente resultado = service.autenticar(email, senha);
    
    assertNotNull(resultado);
    assertEquals(cliente.getEmail(), resultado.getEmail());
}
```

### CRUD

```java
@Test
void testCadastrar_ComDadosValidos_DeveRetornarSucesso() {
    when(repository.existsByEmail(email)).thenReturn(false);
    when(repository.save(any(Cliente.class))).thenReturn(cliente);
    
    String resultado = service.cadastrar(dados);
    
    assertEquals("Cliente cadastrado com sucesso", resultado);
    verify(repository, times(1)).save(any(Cliente.class));
}
```

## Planos de Testes Futuros

### Prioridade 1 (Crítico)
1. ClienteServiceTest - Validações e autenticação críticas
2. UsuarioServiceTest - Autenticação do backoffice
3. LoginControllerTest - Controle de acesso

### Prioridade 2 (Importante)
4. ProdutoServiceTest - Gestão de produtos e estoque
5. ProdutoControllerTest - Interface de gestão

### Prioridade 3 (Complementar)
6. ViaCepServiceTest - Integração externa
7. Testes de Models restantes
8. Testes adicionais de controllers (casos de borda)

Para detalhes completos, consulte `docs/PLANO_TESTES.md`.

## Boas Práticas

### 1. Isolamento
- Usar mocks para dependências externas
- Não depender de banco de dados real
- Isolar cada teste

### 2. Nomenclatura Clara
- Nomes descritivos que explicam o teste
- Seguir padrão estabelecido
- Documentar cenários complexos

### 3. Organização
- Um teste por cenário
- Organizar em métodos setUp() quando necessário
- Agrupar testes relacionados

### 4. Asserts Significativos
- Usar asserts específicos
- Verificar comportamento esperado
- Verificar chamadas de métodos mockados

### 5. Manutenibilidade
- Reutilizar fixtures em @BeforeEach
- Extrair lógica comum
- Manter testes simples e focados

---

Para mais informações sobre planos de testes, consulte `docs/PLANO_TESTES.md`.

