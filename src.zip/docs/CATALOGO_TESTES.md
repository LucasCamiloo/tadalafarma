# Catálogo Completo de Testes - Tadalafarma

## 📊 Resumo Geral

**Total de Testes Catalogados**: 315  
**Data de Catalogação**: 2024

---

## 📁 Estrutura do Catálogo

- [Controllers](#controllers) - 84 testes
- [Services](#services) - 258 testes  
- [Models](#models) - 58 testes

---

## 🎮 Controllers

### BackofficeControllerTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/BackofficeControllerTest.java`  
**Total de Testes**: 44

#### Gestão de Pedidos (10 testes)
1. **testListarPedidos_QuandoUsuarioLogado_DeveRetornarListaDePedidos**
   - Verifica listagem de pedidos com usuário autenticado
   
2. **testListarPedidos_QuandoUsuarioNaoLogado_DeveRedirecionarParaLogin**
   - Verifica redirecionamento quando não autenticado
   
3. **testEditarPedido_QuandoPedidoExiste_DeveRetornarTelaDeEdicao**
   - Verifica exibição da tela de edição para pedido existente
   
4. **testEditarPedido_QuandoPedidoNaoExiste_DeveRedirecionarComErro**
   - Verifica tratamento de pedido inexistente
   
5. **testProcessarEdicaoPedido_ComStatusValido_DeveAtualizarERedirecionar**
   - Verifica atualização de status válido
   
6. **testProcessarEdicaoPedido_ComStatusInvalido_DeveRetornarErro**
   - Verifica tratamento de status inválido
   
7. **testProcessarEdicaoPedido_QuandoPedidoNaoExiste_DeveRedirecionarComErro**
   - Verifica tratamento quando pedido não existe
   
8. **testListarPedidos_ComMensagemSucesso_DeveIncluirMensagem**
   - Verifica exibição de mensagem de sucesso
   
9. **testListarPedidos_ComMensagemErro_DeveIncluirErro**
   - Verifica exibição de mensagem de erro
   
10. **testEditarPedido_QuandoUsuarioNaoLogado_DeveRedirecionarParaLogin**
    - Verifica controle de acesso não autenticado

#### Backoffice Principal (4 testes)
11. **testBackoffice_ComUsuarioLogado_DeveRetornarTelaPrincipal**
    - Verifica acesso à tela principal do backoffice
    
12. **testBackoffice_ComUsuarioAdmin_DeveMarcarIsAdminComoTrue**
    - Verifica identificação de usuário admin
    
13. **testBackoffice_ComUsuarioEstoquista_DeveMarcarIsAdminComoFalse**
    - Verifica identificação de usuário estoquista
    
14. **testBackoffice_SemUsuarioLogado_DeveRedirecionarParaLogin**
    - Verifica controle de acesso

#### Gestão de Usuários (30 testes)
15. **testListarUsuarios_ComAdminLogado_DeveRetornarLista**
    - Verifica listagem de usuários por admin
    
16. **testListarUsuarios_ComEstoquista_DeveRedirecionarComErro**
    - Verifica restrição de acesso para estoquista
    
17. **testListarUsuarios_SemUsuarioLogado_DeveRedirecionarParaLogin**
    - Verifica controle de acesso
    
18. **testProcessarAcaoUsuario_ComAcaoZero_DeveRedirecionarParaBackoffice**
    - Verifica ação de cancelamento
    
19. **testProcessarAcaoUsuario_ComAcaoI_DeveRedirecionarParaCadastrar**
    - Verifica redirecionamento para cadastro
    
20. **testProcessarAcaoUsuario_ComIdValido_DeveRedirecionarParaOpcoes**
    - Verifica redirecionamento para opções do usuário
    
21. **testProcessarAcaoUsuario_ComIdInvalido_DeveRedirecionarComErro**
    - Verifica tratamento de ID inválido
    
22. **testCadastrarUsuario_Get_ComAdmin_DeveRetornarFormulario**
    - Verifica exibição do formulário de cadastro
    
23. **testProcessarCadastro_ComDadosValidos_DeveCadastrarComSucesso**
    - Verifica cadastro com dados válidos
    
24. **testProcessarCadastro_ComDadosInvalidos_DeveRetornarErro**
    - Verifica tratamento de dados inválidos
    
25. **testProcessarCadastro_ComGrupoInvalido_DeveRetornarErro**
    - Verifica tratamento de grupo inválido
    
26. **testOpcoesUsuario_Get_ComUsuarioExistente_DeveRetornarOpcoes**
    - Verifica exibição de opções do usuário
    
27. **testOpcoesUsuario_Get_ComUsuarioInexistente_DeveRedirecionarComErro**
    - Verifica tratamento de usuário inexistente
    
28. **testProcessarOpcaoUsuario_ComOpcao1_DeveRedirecionarParaAlterar**
    - Verifica opção de alterar dados
    
29. **testProcessarOpcaoUsuario_ComOpcao2_DeveRedirecionarParaSenha**
    - Verifica opção de alterar senha
    
30. **testProcessarOpcaoUsuario_ComOpcao3_DeveRedirecionarParaStatus**
    - Verifica opção de alterar status
    
31. **testProcessarOpcaoUsuario_ComOpcao4_DeveRedirecionarParaUsuarios**
    - Verifica opção de voltar
    
32. **testProcessarOpcaoUsuario_ComOpcaoInvalida_DeveRedirecionarComErro**
    - Verifica tratamento de opção inválida
    
33. **testAlterarUsuario_Get_ComUsuarioExistente_DeveRetornarFormulario**
    - Verifica exibição do formulário de alteração
    
34. **testProcessarAlteracao_ComSalvarN_DeveRedirecionarParaOpcoes**
    - Verifica cancelamento de alteração
    
35. **testProcessarAlteracao_ComDadosValidos_DeveAlterarComSucesso**
    - Verifica alteração com dados válidos
    
36. **testAlterarSenha_Get_ComUsuarioExistente_DeveRetornarFormulario**
    - Verifica exibição do formulário de senha
    
37. **testProcessarAlteracaoSenha_ComSalvarN_DeveRedirecionarParaOpcoes**
    - Verifica cancelamento de alteração de senha
    
38. **testProcessarAlteracaoSenha_ComSenhasValidas_DeveAlterarComSucesso**
    - Verifica alteração de senha com sucesso
    
39. **testAlterarStatus_Get_ComUsuarioExistente_DeveRetornarFormulario**
    - Verifica exibição do formulário de status
    
40. **testProcessarAlteracaoStatus_ComSalvarN_DeveRedirecionarParaOpcoes**
    - Verifica cancelamento de alteração de status
    
41. **testProcessarAlteracaoStatus_ComSalvarS_DeveAlterarStatus**
    - Verifica alteração de status com sucesso
    
42. **testProcessarEdicaoPedido_QuandoUsuarioNaoLogado_DeveRedirecionarParaLogin**
    - Verifica controle de acesso na edição de pedido

---

### ClienteControllerTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/ClienteControllerTest.java`  
**Total de Testes**: 50

#### Detalhes de Pedido (5 testes)
43. **testDetalhesPedido_QuandoPedidoExisteEPertenceAoCliente_DeveRetornarDetalhes**
    - Verifica exibição de detalhes do pedido
    
44. **testDetalhesPedido_QuandoClienteNaoLogado_DeveRedirecionarParaLogin**
    - Verifica controle de acesso
    
45. **testDetalhesPedido_QuandoPedidoNaoExiste_DeveRedirecionarComErro**
    - Verifica tratamento de pedido inexistente
    
46. **testDetalhesPedido_QuandoPedidoNaoPertenceAoCliente_DeveRedirecionarComErro**
    - Verifica controle de acesso ao pedido
    
47. **testDetalhesPedido_DeveExibirTodosOsDadosDoPedido**
    - Verifica exibição completa dos dados

#### Cadastro (3 testes)
48. **testCadastro_Get_DeveRetornarFormulario**
    - Verifica exibição do formulário de cadastro
    
49. **testProcessarCadastro_ComDadosValidos_DeveRedirecionarParaLogin**
    - Verifica cadastro com sucesso
    
50. **testProcessarCadastro_ComDadosInvalidos_DeveRetornarErro**
    - Verifica tratamento de dados inválidos

#### Login (4 testes)
51. **testLogin_Get_DeveRetornarFormulario**
    - Verifica exibição do formulário de login
    
52. **testProcessarLogin_ComCredenciaisValidas_DeveRedirecionarParaPerfil**
    - Verifica login com credenciais válidas
    
53. **testProcessarLogin_ComCredenciaisInvalidas_DeveRetornarErro**
    - Verifica tratamento de credenciais inválidas
    
54. **testProcessarLogin_ComRedirecionamentoAposLogin_DeveRedirecionarParaCheckout**
    - Verifica redirecionamento após login

#### Logout (1 teste)
55. **testLogout_DeveRemoverSessaoERedirecionar**
    - Verifica encerramento de sessão

#### Perfil (2 testes)
56. **testPerfil_ComClienteLogado_DeveRetornarPerfil**
    - Verifica exibição do perfil
    
57. **testPerfil_SemClienteLogado_DeveRedirecionarParaLogin**
    - Verifica controle de acesso

#### Alterar Dados (3 testes)
58. **testAlterarDados_Get_ComClienteLogado_DeveRetornarFormulario**
    - Verifica exibição do formulário
    
59. **testProcessarAlteracaoDados_ComDadosValidos_DeveAtualizarESucesso**
    - Verifica alteração com sucesso
    
60. **testProcessarAlteracaoDados_ComDadosInvalidos_DeveRetornarErro**
    - Verifica tratamento de dados inválidos

#### Alterar Senha (3 testes)
61. **testAlterarSenha_Get_ComClienteLogado_DeveRetornarFormulario**
    - Verifica exibição do formulário
    
62. **testProcessarAlteracaoSenha_ComSenhasValidas_DeveAlterarComSucesso**
    - Verifica alteração com sucesso
    
63. **testProcessarAlteracaoSenha_ComSenhasDiferentes_DeveRetornarErro**
    - Verifica tratamento de senhas diferentes

#### Endereços (2 testes)
64. **testGerenciarEnderecos_ComClienteLogado_DeveRetornarLista**
    - Verifica listagem de endereços
    
65. **testAdicionarEndereco_Get_ComClienteLogado_DeveRetornarFormulario**
    - Verifica exibição do formulário

#### Meus Pedidos (2 testes)
66. **testMeusPedidos_ComClienteLogado_DeveRetornarLista**
    - Verifica listagem de pedidos do cliente
    
67. **testMeusPedidos_SemClienteLogado_DeveRedirecionarParaLogin**
    - Verifica controle de acesso

#### API CEP (1 teste)
68. **testBuscarCep_ComCepValido_DeveRetornarEndereco**
    - Verifica busca de endereço por CEP

#### Checkout (23 testes)
69. **testIniciarCheckout_ComClienteLogadoECarrinho_DeveRedirecionarParaEndereco**
    - Verifica início do checkout
    
70. **testIniciarCheckout_SemClienteLogado_DeveRedirecionarParaLogin**
    - Verifica controle de acesso
    
71. **testIniciarCheckout_ComCarrinhoVazio_DeveRedirecionarComErro**
    - Verifica tratamento de carrinho vazio
    
72. **testEscolherEndereco_ComClienteLogado_DeveRetornarFormulario**
    - Verifica exibição do formulário
    
73. **testEscolherEndereco_SemClienteLogado_DeveRedirecionarParaLogin**
    - Verifica controle de acesso
    
74. **testProcessarEnderecoEscolhido_ComEnderecoValido_DeveRedirecionarParaPagamento**
    - Verifica processamento de endereço
    
75. **testProcessarEnderecoEscolhido_ComEnderecoInvalido_DeveRetornarErro**
    - Verifica tratamento de endereço inválido
    
76. **testAdicionarEnderecoCheckout_ComClienteLogado_DeveRetornarFormulario**
    - Verifica exibição do formulário
    
77. **testProcessarAdicaoEnderecoCheckout_ComDadosValidos_DeveAdicionarERedirecionar**
    - Verifica adição de endereço
    
78. **testEscolherPagamento_ComClienteLogadoEEndereco_DeveRetornarFormulario**
    - Verifica exibição do formulário
    
79. **testEscolherPagamento_SemEndereco_DeveRedirecionarParaEndereco**
    - Verifica validação de endereço
    
80. **testProcessarFormaPagamento_ComBoleto_DeveRedirecionarParaResumo**
    - Verifica processamento de boleto
    
81. **testProcessarFormaPagamento_ComCartaoValido_DeveRedirecionarParaResumo**
    - Verifica processamento de cartão
    
82. **testProcessarFormaPagamento_ComFormaInvalida_DeveRetornarErro**
    - Verifica tratamento de forma inválida
    
83. **testVoltarCheckout_DeveRedirecionarParaPagamento**
    - Verifica ação de voltar
    
84. **testAlterarEnderecoPadrao_ComEnderecoValido_DeveAlterarERedirecionar**
    - Verifica alteração de endereço padrão
    
85. **testProcessarAdicaoEndereco_ComDadosValidos_DeveAdicionarComSucesso**
    - Verifica adição de endereço
    
86. **testResumoPedido_ComDadosCompletos_DeveRetornarResumo**
    - Verifica exibição do resumo
    
87. **testResumoPedido_ComCarrinhoVazio_DeveRedirecionar**
    - Verifica validação de carrinho
    
88. **testResumoPedido_SemEndereco_DeveRedirecionar**
    - Verifica validação de endereço
    
89. **testResumoPedido_SemFormaPagamento_DeveRedirecionar**
    - Verifica validação de pagamento
    
90. **testFinalizarPedido_ComDadosValidos_DeveCriarPedido**
    - Verifica finalização do pedido
    
91. **testFinalizarPedido_ComCarrinhoVazio_DeveRedirecionar**
    - Verifica validação de carrinho
    
92. **testFinalizarPedido_ComErroNaCriacao_DeveRetornarErro**
    - Verifica tratamento de erro

---

### LojaControllerTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/LojaControllerTest.java`  
**Total de Testes**: 20

#### Cálculo de Frete (7 testes)
93. **testCalcularFretePorCEP_ComCEPValido_DeveRedirecionarParaCarrinho**
    - Verifica cálculo de frete com CEP válido
    
94. **testCalcularFretePorCEP_ComCEPInvalido_DeveRedirecionarComErro**
    - Verifica tratamento de CEP inválido
    
95. **testCalcularFretePorCEP_ComCEPVazio_DeveRedirecionarComErro**
    - Verifica tratamento de CEP vazio
    
96. **testCalcularFretePorCEP_ComCEPComFormatacao_DeveFuncionar**
    - Verifica processamento de CEP formatado
    
97. **testCalcularFretePorCEP_ComCEPSemFormatacao_DeveFuncionar**
    - Verifica processamento de CEP sem formatação
    
98. **testCalcularFretePorCEP_ComCEPDoRioDeJaneiro_DeveFuncionar**
    - Verifica cálculo para região específica
    
99. **testCalcularFretePorCEP_NaoRequerLogin_DeveFuncionarSemSessao**
    - Verifica que não requer autenticação

#### Lista de Produtos (2 testes)
100. **testIndex_DeveRetornarListaDeProdutos**
     - Verifica listagem de produtos
     
101. **testIndex_ComMensagem_DeveIncluirMensagemNoModelo**
     - Verifica exibição de mensagens

#### Detalhe do Produto (1 teste)
102. **testDetalheProduto_ComProdutoInexistente_DeveRedirecionarParaLoja**
     - Verifica tratamento de produto inexistente

#### Carrinho (10 testes)
103. **testAdicionarAoCarrinho_ComAcaoCarrinho_DeveRedirecionarParaCarrinho**
     - Verifica adição ao carrinho
     
104. **testAdicionarAoCarrinho_ComAcaoContinuar_DeveRedirecionarParaLoja**
     - Verifica ação de continuar comprando
     
105. **testVerCarrinho_ComCarrinhoVazio_DeveRetornarCarrinhoVazio**
     - Verifica exibição de carrinho vazio
     
106. **testAumentarQuantidade_DeveIncrementarQuantidade**
     - Verifica aumento de quantidade
     
107. **testDiminuirQuantidade_ComQuantidadeMaiorQueUm_DeveDiminuir**
     - Verifica diminuição de quantidade
     
108. **testDiminuirQuantidade_ComQuantidadeIgualAUm_DeveRemoverDoCarrinho**
     - Verifica remoção quando quantidade = 1
     
109. **testRemoverProduto_DeveRemoverDoCarrinho**
     - Verifica remoção de produto
     
110. **testAtualizarFrete_DeveAtualizarFreteNaSessao**
     - Verifica atualização de frete

---

### LoginControllerTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/LoginControllerTest.java`  
**Total de Testes**: 8

111. **testIndex_DeveRedirecionarParaLoja**
    - Verifica redirecionamento inicial
    
112. **testLogin_Get_DeveRetornarFormulario**
    - Verifica exibição do formulário
    
113. **testLogin_Post_ComCredenciaisValidas_DeveRedirecionarParaBackoffice**
    - Verifica login com sucesso
    
114. **testLogin_Post_ComCredenciaisInvalidas_DeveRetornarErro**
    - Verifica tratamento de credenciais inválidas
    
115. **testLogin_Post_ComUsuarioInativo_DeveRetornarErro**
    - Verifica tratamento de usuário inativo
    
116. **testLogin_Post_ComEmailNaoExiste_DeveRetornarErro**
    - Verifica tratamento de email inexistente
    
117. **testLogout_DeveInvalidarSessaoERedirecionar**
    - Verifica encerramento de sessão
    
118. **testLogin_Post_ComEmailVazio_DeveRetornarErro**
    - Verifica tratamento de email vazio

---

### ProdutoControllerTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/ProdutoControllerTest.java`  
**Total de Testes**: 15

119. **testListarProdutos_ComUsuarioLogado_DeveRetornarLista**
    - Verifica listagem de produtos
    
120. **testListarProdutos_ComBusca_DeveRetornarProdutosFiltrados**
    - Verifica busca de produtos
    
121. **testListarProdutos_SemUsuarioLogado_DeveRedirecionarParaLogin**
    - Verifica controle de acesso
    
122. **testCadastrarProduto_Get_ComAdmin_DeveRetornarFormulario**
    - Verifica exibição do formulário
    
123. **testCadastrarProduto_Get_ComEstoquista_DeveNegarAcesso**
    - Verifica restrição de acesso
    
124. **testCadastrarProduto_Post_ComDadosValidos_DeveRedirecionarParaLista**
    - Verifica cadastro com sucesso
    
125. **testCadastrarProduto_Post_ComErro_DeveRetornarFormularioComErro**
    - Verifica tratamento de erro
    
126. **testAlterarProduto_Get_ComProdutoExistente_DeveRetornarFormulario**
    - Verifica exibição do formulário
    
127. **testAlterarProduto_Get_ComProdutoNaoExiste_DeveRedirecionarComErro**
    - Verifica tratamento de produto inexistente
    
128. **testAlterarProduto_Post_ComAdmin_DevePermitirAlteracaoCompleta**
    - Verifica alteração completa por admin
    
129. **testAlterarProduto_Post_ComEstoquista_DevePermitirApenasQuantidade**
    - Verifica restrição para estoquista
    
130. **testVisualizarProduto_ComAdmin_DeveRetornarVisualizacao**
    - Verifica visualização por admin
    
131. **testVisualizarProduto_ComEstoquista_DeveNegarAcesso**
    - Verifica restrição de acesso
    
132. **testAlterarStatus_ComAdmin_DeveAlterarStatus**
    - Verifica alteração de status
    
133. **testAlterarStatus_ComEstoquista_DeveNegarAcesso**
    - Verifica restrição de acesso

---

## 🔧 Services

### ClienteServiceTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/ClienteServiceTest.java`  
**Total de Testes**: 58

#### Validação de CPF (6 testes)
134. **testValidarCpf_ComCpfValido_DeveRetornarTrue**
    - Valida CPF válido
    
135. **testValidarCpf_ComCpfInvalido_DeveRetornarFalse**
    - Valida CPF inválido
    
136. **testValidarCpf_ComCpfFormatado_DeveRetornarTrue**
    - Valida CPF com formatação
    
137. **testValidarCpf_ComCpfTamanhoIncorreto_DeveRetornarFalse**
    - Valida CPF com tamanho incorreto
    
138. **testValidarCpf_ComCpfTodosDigitosIguais_DeveRetornarFalse**
    - Valida CPF com todos dígitos iguais
    
139. **testValidarCpf_ComCpfNull_DeveRetornarFalse**
    - Valida CPF null

#### Validação de Email (5 testes)
140. **testValidarEmail_ComEmailValido_DeveRetornarTrue**
    - Valida email válido
    
141. **testValidarEmail_ComEmailInvalido_DeveRetornarFalse**
    - Valida email inválido
    
142. **testValidarEmail_ComEmailNull_DeveRetornarFalse**
    - Valida email null
    
143. **testValidarEmail_ComEmailVazio_DeveRetornarFalse**
    - Valida email vazio
    
144. **testValidarEmail_ComEmailApenasEspacos_DeveRetornarFalse**
    - Valida email com apenas espaços

#### Validação de Nome (6 testes)
145. **testValidarNome_ComNomeValido_DeveRetornarTrue**
    - Valida nome válido
    
146. **testValidarNome_ComApenasUmNome_DeveRetornarFalse**
    - Valida nome com apenas uma palavra
    
147. **testValidarNome_ComPalavraMenorQueTresLetras_DeveRetornarFalse**
    - Valida nome com palavra curta
    
148. **testValidarNome_ComNomeNull_DeveRetornarFalse**
    - Valida nome null
    
149. **testValidarNome_ComNomeVazio_DeveRetornarFalse**
    - Valida nome vazio
    
150. **testValidarNome_ComTresPalavrasValidas_DeveRetornarTrue**
    - Valida nome com três palavras

#### Validação de Data de Nascimento (5 testes)
151. **testValidarDataNascimento_ComDataValida_DeveRetornarLocalDate**
    - Valida data válida
    
152. **testValidarDataNascimento_ComDataFutura_DeveRetornarNull**
    - Valida data futura
    
153. **testValidarDataNascimento_ComFormatoInvalido_DeveRetornarNull**
    - Valida formato inválido
    
154. **testValidarDataNascimento_ComDataNull_DeveRetornarNull**
    - Valida data null
    
155. **testValidarDataNascimento_ComDataVazia_DeveRetornarNull**
    - Valida data vazia

#### Validação de Gênero (7 testes)
156. **testValidarGenero_ComGeneroMasculino_DeveRetornarTrue**
    - Valida gênero masculino
    
157. **testValidarGenero_ComGeneroFeminino_DeveRetornarTrue**
    - Valida gênero feminino
    
158. **testValidarGenero_ComGeneroOutro_DeveRetornarTrue**
    - Valida gênero outro
    
159. **testValidarGenero_ComGeneroNaoInformado_DeveRetornarTrue**
    - Valida gênero não informado
    
160. **testValidarGenero_ComGeneroInvalido_DeveRetornarFalse**
    - Valida gênero inválido
    
161. **testValidarGenero_ComGeneroNull_DeveRetornarFalse**
    - Valida gênero null

#### Validação de Endereço (4 testes)
162. **testValidarEndereco_ComEnderecoCompleto_DeveRetornarTrue**
    - Valida endereço completo
    
163. **testValidarEndereco_ComEnderecoNull_DeveRetornarFalse**
    - Valida endereço null
    
164. **testValidarEndereco_ComCepNull_DeveRetornarFalse**
    - Valida CEP null
    
165. **testValidarEndereco_ComLogradouroNull_DeveRetornarFalse**
    - Valida logradouro null

#### Criptografia (3 testes)
166. **testCriptografarSenha_DeveRetornarSenhaCriptografada**
    - Verifica criptografia de senha
    
167. **testVerificarSenha_ComSenhaCorreta_DeveRetornarTrue**
    - Verifica senha correta
    
168. **testVerificarSenha_ComSenhaIncorreta_DeveRetornarFalse**
    - Verifica senha incorreta

#### Autenticação (4 testes)
169. **testAutenticar_ComCredenciaisValidas_DeveRetornarCliente**
    - Verifica autenticação com sucesso
    
170. **testAutenticar_ComSenhaIncorreta_DeveRetornarNull**
    - Verifica senha incorreta
    
171. **testAutenticar_ComClienteInativo_DeveRetornarNull**
    - Verifica cliente inativo
    
172. **testAutenticar_ComEmailNaoExiste_DeveRetornarNull**
    - Verifica email inexistente

#### Verificação de Duplicatas (4 testes)
173. **testEmailJaExiste_ComEmailExistente_DeveRetornarTrue**
    - Verifica email existente
    
174. **testEmailJaExiste_ComEmailNaoExistente_DeveRetornarFalse**
    - Verifica email não existente
    
175. **testCpfJaExiste_ComCpfExistente_DeveRetornarTrue**
    - Verifica CPF existente
    
176. **testCpfJaExiste_ComCpfNaoExistente_DeveRetornarFalse**
    - Verifica CPF não existente

#### Cadastro (3 testes)
177. **testCadastrarCliente_ComDadosValidos_DeveRetornarSucesso**
    - Verifica cadastro com sucesso
    
178. **testCadastrarCliente_ComCpfDuplicado_DeveRetornarErro**
    - Verifica CPF duplicado
    
179. **testCadastrarCliente_ComEmailDuplicado_DeveRetornarErro**
    - Verifica email duplicado
    
180. **testCadastrarCliente_ComSenhasNaoConferem_DeveRetornarErro**
    - Verifica senhas diferentes

#### Busca (3 testes)
181. **testBuscarPorEmail_ComEmailExistente_DeveRetornarCliente**
    - Verifica busca por email
    
182. **testBuscarPorEmail_ComEmailNaoExistente_DeveRetornarNull**
    - Verifica email não encontrado
    
183. **testBuscarPorId_ComIdExistente_DeveRetornarOptionalCliente**
    - Verifica busca por ID

#### Alteração (4 testes)
184. **testAlterarDadosCliente_ComDadosValidos_DeveRetornarSucesso**
    - Verifica alteração com sucesso
    
185. **testAlterarDadosCliente_ComClienteNaoExiste_DeveRetornarErro**
    - Verifica cliente não encontrado
    
186. **testAlterarSenhaCliente_ComDadosValidos_DeveRetornarSucesso**
    - Verifica alteração de senha
    
187. **testAlterarSenhaCliente_ComSenhasNaoConferem_DeveRetornarErro**
    - Verifica senhas diferentes

#### Gerenciamento de Endereços (4 testes)
188. **testAdicionarEnderecoEntrega_ComDadosValidos_DeveRetornarSucesso**
    - Verifica adição de endereço
    
189. **testAlterarEnderecoPadrao_ComEnderecoValido_DeveRetornarSucesso**
    - Verifica alteração de endereço padrão
    
190. **testAlterarEnderecoPadrao_ComClienteSemEnderecos_DeveRetornarErro**
    - Verifica cliente sem endereços
    
191. **testAlterarEnderecoPadrao_ComEnderecoNaoEncontrado_DeveRetornarErro**
    - Verifica endereço não encontrado

---

### ProdutoServiceTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/ProdutoServiceTest.java`  
**Total de Testes**: 24

#### Cadastro (5 testes)
192. **testCadastrarProduto_ComDadosValidos_DeveRetornarSucesso**
    - Verifica cadastro com sucesso
    
193. **testCadastrarProduto_ComNomeVazio_DeveRetornarErro**
    - Verifica nome vazio
    
194. **testCadastrarProduto_ComNomeMaiorQue200Caracteres_DeveRetornarErro**
    - Verifica nome muito longo
    
195. **testCadastrarProduto_ComAvaliacaoInvalida_DeveRetornarErro**
    - Verifica avaliação inválida
    
196. **testCadastrarProduto_ComPrecoZero_DeveRetornarErro**
    - Verifica preço zero
    
197. **testCadastrarProduto_ComEstoqueNegativo_DeveRetornarErro**
    - Verifica estoque negativo

#### Alteração (3 testes)
198. **testAlterarProduto_ComDadosValidos_DeveRetornarSucesso**
    - Verifica alteração com sucesso
    
199. **testAlterarProduto_ComProdutoNaoExiste_DeveRetornarErro**
    - Verifica produto não encontrado
    
200. **testAlterarQuantidadeEstoque_ComQuantidadeValida_DeveRetornarSucesso**
    - Verifica alteração de quantidade
    
201. **testAlterarQuantidadeEstoque_ComQuantidadeNegativa_DeveRetornarErro**
    - Verifica quantidade negativa

#### Status (3 testes)
202. **testAlterarStatus_ComProdutoAtivo_DeveDesativar**
    - Verifica desativação
    
203. **testAlterarStatus_ComProdutoInativo_DeveAtivar**
    - Verifica ativação
    
204. **testAlterarStatus_ComProdutoNaoExiste_DeveRetornarErro**
    - Verifica produto não encontrado

#### Busca (2 testes)
205. **testBuscarPorSequencialId_ComIdExistente_DeveRetornarOptionalProduto**
    - Verifica busca por ID
    
206. **testBuscarPorSequencialId_ComIdNaoExiste_DeveRetornarOptionalVazio**
    - Verifica ID não encontrado

#### Listagem (2 testes)
207. **testListarProdutos_ComBusca_DeveRetornarProdutosFiltrados**
    - Verifica listagem com busca
    
208. **testListarProdutos_SemBusca_DeveRetornarTodosProdutos**
    - Verifica listagem sem busca

#### Imagens (9 testes)
209. **testBuscarImagensProduto_ComProdutoExistente_DeveRetornarLista**
    - Verifica busca de imagens
    
210. **testBuscarImagemPrincipal_ComImagemPrincipal_DeveRetornarOptionalImagem**
    - Verifica busca de imagem principal
    
211. **testDeletarImagem_ComImagemValida_DeveRetornarSucesso**
    - Verifica deleção de imagem
    
212. **testDeletarImagem_ComImagemNaoExiste_DeveRetornarErro**
    - Verifica imagem não encontrada
    
213. **testDefinirImagemPrincipal_ComImagemValida_DeveRetornarSucesso**
    - Verifica definição de imagem principal
    
214. **testDefinirImagemPrincipal_ComImagemNaoExiste_DeveRetornarErro**
    - Verifica imagem não encontrada
    
215. **testDefinirImagemPrincipal_ComImagemDeOutroProduto_DeveRetornarErro**
    - Verifica imagem de outro produto

---

### PedidoServiceTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/PedidoServiceTest.java`  
**Total de Testes**: 7

216. **testBuscarTodosPedidos_DeveRetornarListaOrdenadaPorDataDecrescente**
    - Verifica listagem ordenada
    
217. **testBuscarTodosPedidos_QuandoNaoHaPedidos_DeveRetornarListaVazia**
    - Verifica lista vazia
    
218. **testAtualizarStatusPedido_ComStatusValido_DeveAtualizarComSucesso**
    - Verifica atualização de status
    
219. **testAtualizarStatusPedido_ComTodosStatusValidos_DeveAtualizarComSucesso**
    - Verifica todos os status válidos
    
220. **testAtualizarStatusPedido_QuandoPedidoNaoExiste_DeveRetornarErro**
    - Verifica pedido não encontrado
    
221. **testAtualizarStatusPedido_ComStatusInvalido_DeveRetornarErro**
    - Verifica status inválido
    
222. **testAtualizarStatusPedido_ComStatusNull_DeveRetornarErro**
    - Verifica status null
    
223. **testAtualizarStatusPedido_QuandoOcorreErroAoSalvar_DeveRetornarMensagemDeErro**
    - Verifica tratamento de erro ao salvar

---

### UsuarioServiceTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/UsuarioServiceTest.java`  
**Total de Testes**: 38

#### Validação de CPF (4 testes)
224. **testValidarCpf_ComCpfValido_DeveRetornarTrue**
    - Valida CPF válido
    
225. **testValidarCpf_ComCpfInvalido_DeveRetornarFalse**
    - Valida CPF inválido
    
226. **testValidarCpf_ComCpfFormatado_DeveRetornarTrue**
    - Valida CPF formatado
    
227. **testValidarCpf_ComCpfTodosDigitosIguais_DeveRetornarFalse**
    - Valida CPF com todos dígitos iguais
    
228. **testValidarCpf_ComCpfNull_DeveRetornarFalse**
    - Valida CPF null

#### Validação de Email (4 testes)
229. **testValidarEmail_ComEmailValido_DeveRetornarTrue**
    - Valida email válido
    
230. **testValidarEmail_ComEmailInvalido_DeveRetornarFalse**
    - Valida email inválido
    
231. **testValidarEmail_ComEmailNull_DeveRetornarFalse**
    - Valida email null
    
232. **testValidarEmail_ComEmailVazio_DeveRetornarFalse**
    - Valida email vazio

#### Criptografia (3 testes)
233. **testCriptografarSenha_DeveRetornarSenhaCriptografada**
    - Verifica criptografia
    
234. **testVerificarSenha_ComSenhaCorreta_DeveRetornarTrue**
    - Verifica senha correta
    
235. **testVerificarSenha_ComSenhaIncorreta_DeveRetornarFalse**
    - Verifica senha incorreta

#### Autenticação (4 testes)
236. **testAutenticar_ComCredenciaisValidas_DeveRetornarUsuario**
    - Verifica autenticação com sucesso
    
237. **testAutenticar_ComSenhaIncorreta_DeveRetornarNull**
    - Verifica senha incorreta
    
238. **testAutenticar_ComUsuarioInativo_DeveRetornarNull**
    - Verifica usuário inativo
    
239. **testAutenticar_ComEmailNaoExiste_DeveRetornarNull**
    - Verifica email inexistente

#### Verificação de Duplicatas (4 testes)
240. **testEmailJaExiste_ComEmailExistente_DeveRetornarTrue**
    - Verifica email existente
    
241. **testEmailJaExiste_ComEmailNaoExistente_DeveRetornarFalse**
    - Verifica email não existente
    
242. **testCpfJaExiste_ComCpfExistente_DeveRetornarTrue**
    - Verifica CPF existente
    
243. **testCpfJaExiste_ComCpfNaoExistente_DeveRetornarFalse**
    - Verifica CPF não existente

#### Listagem (2 testes)
244. **testListarTodos_DeveRetornarTodosUsuarios**
    - Verifica listagem completa
    
245. **testListarTodos_ComUsuariosSemSequencialId_DeveGerarIds**
    - Verifica geração de IDs

#### Busca (4 testes)
246. **testBuscarPorId_ComIdExistente_DeveRetornarOptionalUsuario**
    - Verifica busca por ID
    
247. **testBuscarPorSequencialId_ComIdExistente_DeveRetornarOptionalUsuario**
    - Verifica busca por ID sequencial
    
248. **testBuscarPorEmail_ComEmailExistente_DeveRetornarUsuario**
    - Verifica busca por email
    
249. **testBuscarPorEmail_ComEmailNaoExistente_DeveRetornarNull**
    - Verifica email não encontrado

#### Cadastro (4 testes)
250. **testCadastrarUsuario_ComDadosValidos_DeveRetornarSucesso**
    - Verifica cadastro com sucesso
    
251. **testCadastrarUsuario_ComCpfDuplicado_DeveRetornarErro**
    - Verifica CPF duplicado
    
252. **testCadastrarUsuario_ComEmailDuplicado_DeveRetornarErro**
    - Verifica email duplicado
    
253. **testCadastrarUsuario_ComSenhasNaoConferem_DeveRetornarErro**
    - Verifica senhas diferentes
    
254. **testCadastrarUsuario_ComGrupoNull_DeveRetornarErro**
    - Verifica grupo null

#### Alteração (3 testes)
255. **testAlterarUsuario_ComDadosValidos_DeveRetornarSucesso**
    - Verifica alteração com sucesso
    
256. **testAlterarUsuario_ComUsuarioNaoExiste_DeveRetornarErro**
    - Verifica usuário não encontrado
    
257. **testAlterarSenha_ComDadosValidos_DeveRetornarSucesso**
    - Verifica alteração de senha
    
258. **testAlterarSenha_ComSenhasNaoConferem_DeveRetornarErro**
    - Verifica senhas diferentes

#### Status (3 testes)
259. **testAlterarStatus_ComUsuarioAtivo_DeveDesativar**
    - Verifica desativação
    
260. **testAlterarStatus_ComUsuarioInativo_DeveAtivar**
    - Verifica ativação
    
261. **testAlterarStatus_ComUsuarioNaoExiste_DeveRetornarErro**
    - Verifica usuário não encontrado

---

### ViaCepServiceTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/ViaCepServiceTest.java`  
**Total de Testes**: 9

262. **testValidarCep_ComCepValido_DeveRetornarTrue**
    - Valida CEP válido
    
263. **testValidarCep_ComCepInvalido_DeveRetornarFalse**
    - Valida CEP inválido
    
264. **testValidarCep_ComCepVazio_DeveRetornarFalse**
    - Valida CEP vazio
    
265. **testValidarCep_ComCepNull_DeveRetornarFalse**
    - Valida CEP null
    
266. **testBuscarEnderecoPorCep_ComCepInvalido_DeveRetornarNull**
    - Verifica busca com CEP inválido
    
267. **testBuscarEnderecoPorCep_ComCepFormatado_DeveProcessarCorretamente**
    - Verifica processamento de CEP formatado
    
268. **testBuscarEnderecoPorCep_ComCepSemFormatacao_DeveProcessarCorretamente**
    - Verifica processamento de CEP sem formatação
    
269. **testBuscarEnderecoPorCep_ComCepInexistente_DeveRetornarNull**
    - Verifica CEP inexistente
    
270. **testBuscarEnderecoPorCep_ComCepNull_DeveRetornarNull**
    - Verifica CEP null

---

## 📦 Models

### ClienteTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/model/ClienteTest.java`  
**Total de Testes**: 8

271. **testAdicionarEnderecoEntrega_DeveAdicionarNaLista**
    - Verifica adição de endereço
    
272. **testAdicionarEnderecoEntrega_QuandoListaEstaNull_DeveCriarNovaLista**
    - Verifica criação de lista quando null
    
273. **testGetEnderecoPadraoEntrega_ComEnderecoPadrao_DeveRetornarEnderecoPadrao**
    - Verifica retorno de endereço padrão
    
274. **testGetEnderecoPadraoEntrega_SemEnderecoPadrao_DeveRetornarPrimeiro**
    - Verifica retorno do primeiro quando não há padrão
    
275. **testGetEnderecoPadraoEntrega_SemEnderecos_DeveRetornarNull**
    - Verifica retorno null quando não há endereços
    
276. **testDefinirEnderecoPadrao_DeveAlterarFlagPadrao**
    - Verifica alteração de flag padrão
    
277. **testConstrutor_ComParametros_DeveInicializarCorretamente**
    - Verifica inicialização com parâmetros
    
278. **testConstrutor_Padrao_DeveCriarCliente**
    - Verifica construtor padrão

---

### EnderecoTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/model/EnderecoTest.java`  
**Total de Testes**: 6

279. **testGetEnderecoCompleto_ComTodosOsCampos_DeveRetornarFormatado**
    - Verifica formatação completa
    
280. **testGetEnderecoCompleto_SemComplemento_DeveRetornarFormatado**
    - Verifica formatação sem complemento
    
281. **testGetEnderecoCompleto_SemNumero_DeveRetornarFormatado**
    - Verifica formatação sem número
    
282. **testConstrutor_ComParametros_DeveInicializarCorretamente**
    - Verifica inicialização com parâmetros
    
283. **testConstrutor_Padrao_DeveGerarId**
    - Verifica geração de ID

---

### ItemPedidoTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/model/ItemPedidoTest.java`  
**Total de Testes**: 5

284. **testConstrutor_ComParametros_DeveInicializarCorretamente**
    - Verifica inicialização com parâmetros
    
285. **testConstrutor_Padrao_DeveCriarItemPedido**
    - Verifica construtor padrão
    
286. **testCalculoTotal_DeveSerPrecoUnitarioVezesQuantidade**
    - Verifica cálculo de total
    
287. **testGettersESetters_DeveFuncionarCorretamente**
    - Verifica getters e setters

---

### PedidoTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/model/PedidoTest.java`  
**Total de Testes**: 9

288. **testAdicionarItem_DeveAdicionarItemNaLista**
    - Verifica adição de item
    
289. **testAdicionarItem_QuandoListaEstaNull_DeveCriarNovaLista**
    - Verifica criação de lista quando null
    
290. **testSetStatus_DeveAtualizarDataUltimaAtualizacao**
    - Verifica atualização de data
    
291. **testGetStatusTexto_ComTodosStatusValidos_DeveRetornarTextoCorreto**
    - Verifica conversão de status para texto
    
292. **testGetStatusTexto_ComStatusDesconhecido_DeveRetornarStatusOriginal**
    - Verifica status desconhecido
    
293. **testDadosCartao_GetNumeroCartaoMascarado_DeveRetornarMascarado**
    - Verifica mascaramento de cartão
    
294. **testDadosCartao_GetNumeroCartaoMascarado_ComNumeroCurto_DeveRetornarAsteriscos**
    - Verifica mascaramento de número curto
    
295. **testDadosCartao_GetNumeroCartaoMascarado_ComNumeroNull_DeveRetornarAsteriscos**
    - Verifica mascaramento de número null
    
296. **testConstrutor_DeveInicializarDataCriacao**
    - Verifica inicialização de data

---

### ProdutoTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/model/ProdutoTest.java`  
**Total de Testes**: 5

297. **testConstrutor_ComParametros_DeveInicializarCorretamente**
    - Verifica inicialização com parâmetros
    
298. **testConstrutor_Padrao_DeveInicializarDatas**
    - Verifica inicialização de datas
    
299. **testConstrutor_DeveInicializarStatusComoAtivo**
    - Verifica inicialização de status
    
300. **testGettersESetters_DeveFuncionarCorretamente**
    - Verifica getters e setters

---

### ProdutoImagemTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/model/ProdutoImagemTest.java`  
**Total de Testes**: 6

301. **testConstrutor_ComParametros_DeveInicializarCorretamente**
    - Verifica inicialização com parâmetros
    
302. **testConstrutor_Padrao_DeveInicializarDataUpload**
    - Verifica inicialização de data
    
303. **testSetImagemPrincipal_ComTrue_DeveDefinirComoPrincipal**
    - Verifica definição como principal
    
304. **testSetImagemPrincipal_ComFalse_DeveRemoverPrincipal**
    - Verifica remoção de principal
    
305. **testGettersESetters_DeveFuncionarCorretamente**
    - Verifica getters e setters

---

### UsuarioTest
**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/model/UsuarioTest.java`  
**Total de Testes**: 9

306. **testConstrutor_ComParametros_DeveInicializarGrupoCorretamente**
    - Verifica inicialização com parâmetros
    
307. **testConstrutor_ComGrupoEstoquista_DeveInicializarCorretamente**
    - Verifica inicialização com grupo estoquista
    
308. **testConstrutor_ComGrupoNull_DeveSalvarComoNull**
    - Verifica tratamento de grupo null
    
309. **testConstrutor_Padrao_DeveCriarUsuario**
    - Verifica construtor padrão
    
310. **testSetGrupo_ComEnum_DeveSalvarComoString**
    - Verifica salvamento de grupo
    
311. **testGrupo_Administrador_DeveExistir**
    - Verifica existência de grupo administrador
    
312. **testGrupo_Estoquista_DeveExistir**
    - Verifica existência de grupo estoquista
    
313. **testGettersESetters_DeveFuncionarCorretamente**
    - Verifica getters e setters

---

## 📈 Estatísticas por Categoria

| Categoria | Quantidade | Percentual |
|-----------|------------|------------|
| **Controllers** | 97 | 30.8% |
| **Services** | 136 | 43.2% |
| **Models** | 43 | 13.7% |
| **Outros** | 39 | 12.4% |
| **TOTAL** | **315** | **100%** |

---

## 📝 Notas Finais

- Todos os testes seguem o padrão de nomenclatura: `test[NomeDoMetodo]_[Condicao]_[ResultadoEsperado]`
- Os testes estão organizados por funcionalidade dentro de cada classe
- A cobertura de testes abrange validações, autenticação, CRUD e lógica de negócio
- Testes de integração com APIs externas (ViaCEP) requerem conexão com internet ou mock

---

**Última Atualização**: 2024  
**Versão do Catálogo**: 1.0

