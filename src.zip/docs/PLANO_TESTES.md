# Plano Detalhado de Testes - Tadalafarma

## Visão Geral

Este documento descreve o plano completo de testes para o projeto Tadalafarma, incluindo matriz de cobertura, cenários de teste detalhados por componente e estratégia de implementação.

## Matriz de Cobertura

### Estado Atual vs. Meta

| Componente | Estado Atual | Meta | Status |
|------------|--------------|------|--------|
| **PedidoService** | ✅ 100% | 100% | Completo |
| **ClienteService** | ❌ 0% | 80%+ | Pendente |
| **ProdutoService** | ❌ 0% | 80%+ | Pendente |
| **UsuarioService** | ❌ 0% | 80%+ | Pendente |
| **ViaCepService** | ❌ 0% | 70%+ | Pendente |
| **BackofficeController** | ✅ 70% | 80%+ | Parcial |
| **ClienteController** | ⚠️ 20% | 80%+ | Parcial |
| **LojaController** | ⚠️ 15% | 80%+ | Parcial |
| **LoginController** | ❌ 0% | 80%+ | Pendente |
| **ProdutoController** | ❌ 0% | 80%+ | Pendente |
| **Pedido (Model)** | ✅ 90% | 90%+ | Completo |
| **Cliente (Model)** | ❌ 0% | 70%+ | Pendente |
| **Endereco (Model)** | ❌ 0% | 70%+ | Pendente |
| **ItemPedido (Model)** | ❌ 0% | 70%+ | Pendente |
| **Produto (Model)** | ❌ 0% | 70%+ | Pendente |
| **ProdutoImagem (Model)** | ❌ 0% | 70%+ | Pendente |
| **Usuario (Model)** | ❌ 0% | 70%+ | Pendente |

**Cobertura Geral Atual**: ~15%  
**Cobertura Geral Meta**: > 70%

## Planos de Testes por Componente

### 1. ClienteServiceTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/ClienteServiceTest.java`

#### Cenários de Validação de CPF

1. **testValidarCpf_ComCpfValido_DeveRetornarTrue**
   - CPF válido (11144477735)
   - Resultado: true

2. **testValidarCpf_ComCpfInvalido_DeveRetornarFalse**
   - CPF inválido (12345678901)
   - Resultado: false

3. **testValidarCpf_ComCpfFormatado_DeveRetornarTrue**
   - CPF com formatação (111.444.777-35)
   - Resultado: true (remove formatação)

4. **testValidarCpf_ComCpfTamanhoIncorreto_DeveRetornarFalse**
   - CPF com tamanho incorreto
   - Resultado: false

5. **testValidarCpf_ComCpfTodosDigitosIguais_DeveRetornarFalse**
   - CPF: 11111111111
   - Resultado: false

#### Cenários de Validação de Email

6. **testValidarEmail_ComEmailValido_DeveRetornarTrue**
   - Email: teste@exemplo.com
   - Resultado: true

7. **testValidarEmail_ComEmailInvalido_DeveRetornarFalse**
   - Email: email-invalido
   - Resultado: false

8. **testValidarEmail_ComEmailNull_DeveRetornarFalse**
   - Email: null
   - Resultado: false

9. **testValidarEmail_ComEmailVazio_DeveRetornarFalse**
   - Email: ""
   - Resultado: false

#### Cenários de Validação de Nome

10. **testValidarNome_ComNomeValido_DeveRetornarTrue**
    - Nome: "João Silva"
    - Resultado: true

11. **testValidarNome_ComApenasUmNome_DeveRetornarFalse**
    - Nome: "João"
    - Resultado: false

12. **testValidarNome_ComPalavraMenorQueTresLetras_DeveRetornarFalse**
    - Nome: "João Ab"
    - Resultado: false

13. **testValidarNome_ComNomeNull_DeveRetornarFalse**
    - Nome: null
    - Resultado: false

#### Cenários de Validação de Data de Nascimento

14. **testValidarDataNascimento_ComDataValida_DeveRetornarLocalDate**
    - Data: "1990-01-15"
    - Resultado: LocalDate válido

15. **testValidarDataNascimento_ComDataFutura_DeveRetornarNull**
    - Data: data futura
    - Resultado: null

16. **testValidarDataNascimento_ComFormatoInvalido_DeveRetornarNull**
    - Data: "15/01/1990"
    - Resultado: null

#### Cenários de Validação de Gênero

17. **testValidarGenero_ComGeneroValido_DeveRetornarTrue**
    - Gêneros: "masculino", "feminino", "outro", "não informado"
    - Resultado: true para todos

18. **testValidarGenero_ComGeneroInvalido_DeveRetornarFalse**
    - Gênero: "invalido"
    - Resultado: false

#### Cenários de Autenticação

19. **testAutenticar_ComCredenciaisValidas_DeveRetornarCliente**
    - Email e senha corretos
    - Resultado: Cliente não null

20. **testAutenticar_ComSenhaIncorreta_DeveRetornarNull**
    - Senha incorreta
    - Resultado: null

21. **testAutenticar_ComClienteInativo_DeveRetornarNull**
    - Cliente com status false
    - Resultado: null

22. **testAutenticar_ComEmailNaoExiste_DeveRetornarNull**
    - Email não cadastrado
    - Resultado: null

#### Cenários de Cadastro

23. **testCadastrarCliente_ComDadosValidos_DeveRetornarSucesso**
    - Todos os dados válidos
    - Resultado: "Cliente cadastrado com sucesso"

24. **testCadastrarCliente_ComCpfDuplicado_DeveRetornarErro**
    - CPF já cadastrado
    - Resultado: "CPF já cadastrado"

25. **testCadastrarCliente_ComEmailDuplicado_DeveRetornarErro**
    - Email já cadastrado
    - Resultado: "Email já cadastrado"

26. **testCadastrarCliente_ComSenhasNaoConferem_DeveRetornarErro**
    - Senhas diferentes
    - Resultado: "Senhas não conferem"

#### Cenários de Alteração

27. **testAlterarDadosCliente_ComDadosValidos_DeveRetornarSucesso**
    - Dados válidos
    - Resultado: "Dados alterados com sucesso"

28. **testAlterarSenhaCliente_ComDadosValidos_DeveRetornarSucesso**
    - Senha válida
    - Resultado: "Senha alterada com sucesso"

#### Cenários de Endereços

29. **testAdicionarEnderecoEntrega_ComDadosValidos_DeveRetornarSucesso**
    - Endereço válido
    - Resultado: "Endereço adicionado com sucesso"

30. **testAlterarEnderecoPadrao_ComEnderecoValido_DeveRetornarSucesso**
    - Endereço válido
    - Resultado: "Endereço padrão alterado com sucesso"

**Total de Cenários**: 30

---

### 2. ProdutoServiceTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/ProdutoServiceTest.java`

#### Cenários de Cadastro

1. **testCadastrarProduto_ComDadosValidos_DeveRetornarSucesso**
   - Todos os dados válidos
   - Resultado: "Produto cadastrado com sucesso"

2. **testCadastrarProduto_ComNomeVazio_DeveRetornarErro**
   - Nome vazio
   - Resultado: erro

3. **testCadastrarProduto_ComNomeMaiorQue200Caracteres_DeveRetornarErro**
   - Nome > 200 caracteres
   - Resultado: erro

4. **testCadastrarProduto_ComAvaliacaoInvalida_DeveRetornarErro**
   - Avaliação < 1 ou > 5
   - Resultado: erro

5. **testCadastrarProduto_ComPrecoZero_DeveRetornarErro**
   - Preço = 0
   - Resultado: erro

6. **testCadastrarProduto_ComEstoqueNegativo_DeveRetornarErro**
   - Estoque < 0
   - Resultado: erro

#### Cenários de Alteração

7. **testAlterarProduto_ComDadosValidos_DeveRetornarSucesso**
   - Dados válidos
   - Resultado: "Produto alterado com sucesso"

8. **testAlterarProduto_ComProdutoNaoExiste_DeveRetornarErro**
   - Produto não encontrado
   - Resultado: "Produto não encontrado"

9. **testAlterarQuantidadeEstoque_ComQuantidadeValida_DeveRetornarSucesso**
   - Quantidade válida
   - Resultado: sucesso

#### Cenários de Status

10. **testAlterarStatus_ComProdutoAtivo_DeveDesativar**
    - Produto ativo
    - Resultado: status false

11. **testAlterarStatus_ComProdutoInativo_DeveAtivar**
    - Produto inativo
    - Resultado: status true

#### Cenários de Listagem

12. **testListarProdutos_ComBusca_DeveRetornarProdutosFiltrados**
    - Busca por nome
    - Resultado: produtos filtrados

13. **testListarProdutos_SemBusca_DeveRetornarTodosProdutos**
    - Sem busca
    - Resultado: todos os produtos

14. **testListarProdutos_ComPaginacao_DeveRetornarPaginaCorreta**
    - Paginação
    - Resultado: página correta

#### Cenários de Imagens

15. **testSalvarImagem_ComArquivoValido_DeveRetornarSucesso**
    - Arquivo válido
    - Resultado: "Imagem salva com sucesso"

16. **testSalvarImagem_ComArquivoVazio_DeveRetornarErro**
    - Arquivo vazio
    - Resultado: erro

17. **testDefinirImagemPrincipal_ComImagemValida_DeveRetornarSucesso**
    - Imagem válida
    - Resultado: sucesso

18. **testDeletarImagem_ComImagemValida_DeveRetornarSucesso**
    - Imagem válida
    - Resultado: "Imagem deletada com sucesso"

**Total de Cenários**: 18

---

### 3. UsuarioServiceTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/UsuarioServiceTest.java`

#### Cenários de Validação (Similar ao ClienteService)

1. **testValidarCpf_ComCpfValido_DeveRetornarTrue**
2. **testValidarCpf_ComCpfInvalido_DeveRetornarFalse**
3. **testValidarEmail_ComEmailValido_DeveRetornarTrue**
4. **testValidarEmail_ComEmailInvalido_DeveRetornarFalse**

#### Cenários de Autenticação

5. **testAutenticar_ComCredenciaisValidas_DeveRetornarUsuario**
6. **testAutenticar_ComSenhaIncorreta_DeveRetornarNull**
7. **testAutenticar_ComUsuarioInativo_DeveRetornarNull**
8. **testAutenticar_ComEmailNaoExiste_DeveRetornarNull**

#### Cenários de Cadastro

9. **testCadastrarUsuario_ComDadosValidos_DeveRetornarSucesso**
10. **testCadastrarUsuario_ComCpfDuplicado_DeveRetornarErro**
11. **testCadastrarUsuario_ComEmailDuplicado_DeveRetornarErro**
12. **testCadastrarUsuario_ComGrupoInvalido_DeveRetornarErro**

#### Cenários de Alteração

13. **testAlterarUsuario_ComDadosValidos_DeveRetornarSucesso**
14. **testAlterarSenha_ComDadosValidos_DeveRetornarSucesso**
15. **testAlterarStatus_ComUsuarioAtivo_DeveDesativar**
16. **testAlterarStatus_ComUsuarioInativo_DeveAtivar**

#### Cenários de Listagem

17. **testListarTodos_DeveRetornarTodosUsuarios**
18. **testListarTodos_ComUsuariosSemSequencialId_DeveGerarIds**

**Total de Cenários**: 18

---

### 4. ViaCepServiceTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/ViaCepServiceTest.java`

#### Cenários de Busca

1. **testBuscarEnderecoPorCep_ComCepValido_DeveRetornarEndereco**
   - CEP válido (mockar API)
   - Resultado: Endereco não null

2. **testBuscarEnderecoPorCep_ComCepInvalido_DeveRetornarNull**
   - CEP inválido
   - Resultado: null

3. **testBuscarEnderecoPorCep_ComCepFormatado_DeveProcessarCorretamente**
   - CEP: "01310-100"
   - Resultado: processa corretamente

4. **testBuscarEnderecoPorCep_ComCepSemFormatacao_DeveProcessarCorretamente**
   - CEP: "01310100"
   - Resultado: processa corretamente

5. **testBuscarEnderecoPorCep_ComCepInexistente_DeveRetornarNull**
   - CEP não encontrado (mockar erro)
   - Resultado: null

6. **testValidarCep_ComCepValido_DeveRetornarTrue**
   - CEP válido
   - Resultado: true

7. **testValidarCep_ComCepInvalido_DeveRetornarFalse**
   - CEP inválido
   - Resultado: false

**Total de Cenários**: 7

---

### 5. LoginControllerTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/LoginControllerTest.java`

#### Cenários

1. **testIndex_DeveRedirecionarParaLoja**
   - GET /
   - Resultado: redirect /loja

2. **testLogin_Get_DeveRetornarFormulario**
   - GET /backoffice/login
   - Resultado: view "login"

3. **testLogin_Post_ComCredenciaisValidas_DeveRedirecionarParaBackoffice**
   - POST /backoffice/login com credenciais válidas
   - Resultado: redirect /backoffice + sessão criada

4. **testLogin_Post_ComCredenciaisInvalidas_DeveRetornarErro**
   - POST /backoffice/login com credenciais inválidas
   - Resultado: view "login" com erro

5. **testLogin_Post_ComUsuarioInativo_DeveRetornarErro**
   - POST /backoffice/login com usuário inativo
   - Resultado: view "login" com erro

6. **testLogout_DeveInvalidarSessaoERedirecionar**
   - GET /backoffice/logout
   - Resultado: redirect /backoffice/login + sessão invalidada

**Total de Cenários**: 6

---

### 6. ProdutoControllerTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/ProdutoControllerTest.java`

#### Cenários

1. **testListarProdutos_ComUsuarioLogado_DeveRetornarLista**
2. **testListarProdutos_SemUsuarioLogado_DeveRedirecionarParaLogin**
3. **testCadastrarProduto_Get_ComAdmin_DeveRetornarFormulario**
4. **testCadastrarProduto_Get_ComEstoquista_DeveNegarAcesso**
5. **testCadastrarProduto_Post_ComDadosValidos_DeveRedirecionarParaLista**
6. **testAlterarProduto_Get_ComProdutoExistente_DeveRetornarFormulario**
7. **testAlterarProduto_Post_ComAdmin_DevePermitirAlteracaoCompleta**
8. **testAlterarProduto_Post_ComEstoquista_DevePermitirApenasQuantidade**
9. **testVisualizarProduto_ComAdmin_DeveRetornarVisualizacao**
10. **testAlterarStatus_ComAdmin_DeveAlterarStatus**

**Total de Cenários**: 10+

---

### 7. Model Tests

#### ClienteTest

1. **testAdicionarEnderecoEntrega_DeveAdicionarNaLista**
2. **testGetEnderecoPadraoEntrega_ComEnderecoPadrao_DeveRetornarEnderecoPadrao**
3. **testGetEnderecoPadraoEntrega_SemEnderecoPadrao_DeveRetornarPrimeiro**
4. **testDefinirEnderecoPadrao_DeveAlterarFlagPadrao**

#### EnderecoTest

1. **testGetEnderecoCompleto_DeveRetornarEnderecoFormatado**
2. **testConstrutor_ComParametros_DeveInicializarCorretamente**

#### ItemPedidoTest

1. **testConstrutor_ComParametros_DeveInicializarCorretamente**
2. **testCalculoTotal_DeveSerPrecoUnitarioVezesQuantidade**

#### ProdutoTest

1. **testConstrutor_ComParametros_DeveInicializarCorretamente**
2. **testConstrutor_DeveInicializarDatas**

#### ProdutoImagemTest

1. **testConstrutor_ComParametros_DeveInicializarCorretamente**
2. **testConstrutor_DeveInicializarDataUpload**

#### UsuarioTest

1. **testConstrutor_ComParametros_DeveInicializarGrupoCorretamente**
2. **testSetGrupo_ComEnum_DeveSalvarComoString**

---

## Estratégia de Implementação

### Prioridade 1 (Crítico) - Autenticação e Validações

1. **ClienteServiceTest** - Validações críticas de CPF, email, nome
2. **UsuarioServiceTest** - Autenticação do backoffice
3. **LoginControllerTest** - Controle de acesso

**Prazo**: 1-2 dias

### Prioridade 2 (Importante) - Gestão de Dados

4. **ProdutoServiceTest** - Gestão de produtos e estoque
5. **ProdutoControllerTest** - Interface de gestão

**Prazo**: 1-2 dias

### Prioridade 3 (Complementar) - Integrações e Models

6. **ViaCepServiceTest** - Integração externa
7. **Testes de Models** - Lógica de negócio das entidades

**Prazo**: 1 dia

**Prazo Total Estimado**: 3-5 dias

---

## Estratégia de Mocks

### Services

```java
@Mock
private Repository repository;

@Mock
private ExternalService externalService;

@InjectMocks
private Service service;
```

### Controllers

```java
@MockBean
private Service service;

@Autowired
private MockMvc mockMvc;
```

### Fixtures

```java
@BeforeEach
void setUp() {
    // Criar objetos de teste
    cliente = new Cliente();
    cliente.setId("cliente1");
    // ...
}
```

---

## Métricas de Cobertura Esperadas

### Cobertura por Componente

| Componente | Linhas | Branches | Métodos | Classes |
|------------|--------|----------|---------|---------|
| Services | > 80% | > 75% | > 85% | 100% |
| Controllers | > 70% | > 65% | > 80% | 100% |
| Models | > 70% | > 65% | > 80% | 100% |

### Cobertura Geral

- **Meta**: > 70% de cobertura geral
- **Mínimo Aceitável**: > 60% de cobertura geral
- **Ideal**: > 80% de cobertura geral

---

## Checklist de Implementação

### Antes de Implementar

- [ ] Revisar código do componente
- [ ] Identificar métodos a testar
- [ ] Listar cenários de teste
- [ ] Preparar fixtures e mocks

### Durante Implementação

- [ ] Criar classe de teste
- [ ] Configurar mocks e fixtures
- [ ] Implementar testes unitários
- [ ] Implementar testes de integração (se necessário)
- [ ] Verificar execução dos testes

### Após Implementação

- [ ] Executar todos os testes
- [ ] Verificar cobertura de código
- [ ] Revisar testes com código
- [ ] Documentar testes complexos

---

## Ferramentas de Cobertura

### JaCoCo

Plugin Maven para geração de relatórios de cobertura.

**Comando**:
```bash
mvn clean test jacoco:report
```

**Relatório**: `target/site/jacoco/index.html`

---

## Notas Finais

- Todos os testes devem ser independentes
- Usar mocks para dependências externas
- Testar casos de sucesso e erro
- Testar casos de borda
- Manter testes simples e focados
- Documentar testes complexos

---

**Data de Criação**: 2024  
**Última Atualização**: 2024  
**Versão**: 1.0

