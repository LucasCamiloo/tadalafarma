# Guia de Uso do JaCoCo - Análise de Cobertura de Código

## O que é JaCoCo?

JaCoCo (Java Code Coverage) é uma ferramenta de análise de cobertura de código para projetos Java. Ela mede quantas linhas, branches (ramos), métodos e classes do seu código foram executadas durante os testes.

## Configuração no Projeto

O JaCoCo já está configurado no arquivo `pom.xml` do projeto. A configuração inclui:

- **prepare-agent**: Prepara o agente JaCoCo para instrumentar o código durante a execução dos testes
- **report**: Gera o relatório HTML de cobertura após a execução dos testes
- **check**: Verifica se a cobertura atinge os limites mínimos configurados

## Como Usar

### 1. Executar Testes com Cobertura

Para executar todos os testes e gerar o relatório de cobertura:

```bash
mvn clean test
```

Ou explicitamente:

```bash
mvn clean test jacoco:report
```

### 2. Visualizar o Relatório

Após executar os testes, o relatório HTML será gerado em:

```
target/site/jacoco/index.html
```

**Para abrir o relatório:**
- Navegue até a pasta `target/site/jacoco/`
- Abra o arquivo `index.html` no seu navegador
- Ou use o comando: `start target/site/jacoco/index.html` (Windows) ou `open target/site/jacoco/index.html` (Mac/Linux)

### 3. Executar Testes Específicos com Cobertura

Para executar um teste específico e gerar cobertura:

```bash
mvn test -Dtest=PedidoServiceTest jacoco:report
```

Para executar todos os testes de um pacote:

```bash
mvn test -Dtest=com.tadalafarma.Tadalafarma.service.* jacoco:report
```

### 4. Verificar Limites de Cobertura

O JaCoCo está configurado para verificar se a cobertura atinge os limites mínimos:

- **Linhas por Pacote**: Mínimo de 60%
- **Linhas por Classe**: Mínimo de 70%

Para executar a verificação:

```bash
mvn test jacoco:check
```

Se a cobertura estiver abaixo dos limites, o build falhará.

## Entendendo o Relatório

### Visão Geral

O relatório HTML mostra:

1. **Cobertura Geral do Projeto**
   - Total de instruções
   - Cobertura de branches (ramos)
   - Cobertura de linhas
   - Cobertura de métodos
   - Cobertura de classes

2. **Cobertura por Pacote**
   - Cobertura de cada pacote (controller, service, model, etc.)
   - Número de classes cobertas

3. **Cobertura por Classe**
   - Métricas detalhadas de cada classe
   - Linhas cobertas vs. não cobertas
   - Branches cobertos vs. não cobertos

### Cores no Relatório

- 🟢 **Verde**: Código totalmente coberto
- 🟡 **Amarelo**: Código parcialmente coberto
- 🔴 **Vermelho**: Código não coberto

### Métricas Explicadas

#### Instruction Coverage (Cobertura de Instruções)
- Mede quantas instruções Java bytecode foram executadas
- Uma instrução é a menor unidade de código Java

#### Branch Coverage (Cobertura de Ramos)
- Mede quantos ramos de decisão (if/else, switch, etc.) foram testados
- Exemplo: `if (x > 0)` tem 2 ramos (true e false)

#### Line Coverage (Cobertura de Linhas)
- Mede quantas linhas de código fonte foram executadas
- Uma linha é considerada coberta se pelo menos uma instrução nela foi executada

#### Method Coverage (Cobertura de Métodos)
- Mede quantos métodos foram executados pelo menos uma vez

#### Class Coverage (Cobertura de Classes)
- Mede quantas classes tiveram pelo menos um método executado

## Interpretando os Resultados

### Exemplo de Relatório

```
Cobertura Geral: 45%
- Instructions: 2,450 / 5,432 (45.1%)
- Branches: 180 / 420 (42.9%)
- Lines: 520 / 1,200 (43.3%)
- Methods: 85 / 200 (42.5%)
- Classes: 12 / 20 (60.0%)
```

**Interpretação:**
- 45% do código foi testado
- 520 de 1,200 linhas foram executadas
- 180 de 420 branches foram testados
- 12 de 20 classes foram testadas

### Identificando Áreas Não Cobertas

1. **Navegue pelo relatório HTML**
2. **Clique em um pacote** para ver as classes
3. **Clique em uma classe** para ver o código fonte
4. **Linhas vermelhas** = não cobertas
5. **Linhas amarelas** = parcialmente cobertas
6. **Linhas verdes** = totalmente cobertas

## Melhorando a Cobertura

### 1. Identifique Componentes Não Cobertos

No relatório, procure por:
- Classes com 0% de cobertura
- Métodos não testados
- Branches não testados (if/else, switch)

### 2. Priorize Componentes Críticos

Foque primeiro em:
- Services (lógica de negócio)
- Controllers (endpoints principais)
- Validações importantes

### 3. Adicione Testes

Para cada componente não coberto:
1. Crie uma classe de teste
2. Teste casos de sucesso
3. Teste casos de erro
4. Teste casos de borda (valores limites)

### 4. Verifique a Cobertura Novamente

```bash
mvn clean test jacoco:report
```

## Comandos Úteis

### Limpar e Executar Tudo

```bash
mvn clean test jacoco:report
```

### Apenas Gerar Relatório (sem executar testes)

```bash
mvn jacoco:report
```

### Verificar Limites

```bash
mvn test jacoco:check
```

### Executar com Cobertura e Verificar

```bash
mvn clean test jacoco:report jacoco:check
```

## Configuração Avançada

### Alterar Limites de Cobertura

Edite o arquivo `pom.xml`, na seção `<configuration>` do plugin JaCoCo:

```xml
<limit>
    <counter>LINE</counter>
    <value>COVEREDRATIO</value>
    <minimum>0.70</minimum>  <!-- Altere aqui (0.70 = 70%) -->
</limit>
```

### Excluir Classes do Relatório

Para excluir classes específicas (ex: configurações, DTOs):

```xml
<configuration>
    <excludes>
        <exclude>**/config/**</exclude>
        <exclude>**/dto/**</exclude>
    </excludes>
</configuration>
```

## Integração com IDEs

### IntelliJ IDEA

1. Execute os testes com cobertura: `Run 'All Tests' with Coverage`
2. O relatório aparece na aba "Coverage"
3. Você pode ver a cobertura diretamente no código fonte

### Eclipse

1. Instale o plugin EclEmma (JaCoCo para Eclipse)
2. Execute os testes com cobertura: `Run As > Coverage As > JUnit Test`
3. Visualize a cobertura no código fonte

### VS Code

1. Instale a extensão "Java Test Runner"
2. Execute testes com cobertura
3. Visualize no painel de testes

## Metas de Cobertura do Projeto

### Metas Atuais

- **Cobertura Geral**: > 70% (meta), > 60% (mínimo)
- **Services**: > 80% de linhas, > 75% de branches
- **Controllers**: > 70% de linhas, > 65% de branches
- **Models**: > 70% de linhas, > 65% de branches

### Estado Atual

Execute o relatório para ver a cobertura atual:

```bash
mvn clean test jacoco:report
```

Depois abra `target/site/jacoco/index.html` para visualizar.

## Dicas e Boas Práticas

1. **Execute cobertura regularmente**: Após adicionar novos testes
2. **Foque em qualidade, não quantidade**: 100% de cobertura não garante 0 bugs
3. **Teste casos de erro**: Não apenas casos de sucesso
4. **Mantenha testes simples**: Testes complexos são difíceis de manter
5. **Use mocks adequadamente**: Isole dependências externas
6. **Documente testes complexos**: Adicione comentários quando necessário

## Troubleshooting

### Problema: Relatório não é gerado

**Solução:**
```bash
mvn clean
mvn test jacoco:report
```

### Problema: Cobertura mostra 0%

**Solução:**
- Verifique se os testes estão sendo executados
- Verifique se há erros nos testes
- Execute `mvn clean` antes de executar novamente

### Problema: Build falha no jacoco:check

**Solução:**
- A cobertura está abaixo dos limites mínimos
- Aumente a cobertura ou ajuste os limites no `pom.xml`

## Referências

- [Documentação Oficial JaCoCo](https://www.jacoco.org/jacoco/)
- [JaCoCo Maven Plugin](https://www.jacoco.org/jacoco/trunk/doc/maven.html)
- [Entendendo Cobertura de Código](https://www.jacoco.org/jacoco/trunk/doc/counters.html)

---

**Última Atualização**: [Data]  
**Versão do JaCoCo**: 0.8.11

