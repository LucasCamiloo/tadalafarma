# Guia de Desenvolvimento - Tadalafarma

Este guia fornece informações sobre como configurar o ambiente de desenvolvimento, padrões de código, estrutura de commits e como adicionar novas funcionalidades ao projeto.

## Configuração do Ambiente de Desenvolvimento

### Pré-requisitos

1. **Java 17** ou superior
   - Verificar instalação: `java -version`
   - Download: [Oracle JDK](https://www.oracle.com/java/technologies/downloads/) ou [OpenJDK](https://adoptium.net/)

2. **Maven 3.6+**
   - Verificar instalação: `mvn -version`
   - Download: [Apache Maven](https://maven.apache.org/download.cgi)

3. **MongoDB**
   - **Opção 1**: MongoDB local
     - Download: [MongoDB Community](https://www.mongodb.com/try/download/community)
   - **Opção 2**: MongoDB Atlas (Cloud)
     - Criar conta: [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)

4. **IDE** (Escolha uma)
   - **IntelliJ IDEA** (Recomendado)
   - **Eclipse IDE**
   - **VS Code** com extensões Java

### Configuração do Projeto

1. **Clone o repositório**
```bash
git clone <url-do-repositorio>
cd tadalafarma-main
```

2. **Configure o MongoDB**

Edite `src/main/resources/application.properties`:

```properties
# MongoDB local
spring.data.mongodb.uri=mongodb://localhost:27017/tadalafarma

# Ou MongoDB Atlas
spring.data.mongodb.uri=mongodb+srv://usuario:senha@cluster.mongodb.net/tadalafarma?retryWrites=true&w=majority
```

3. **Importe o projeto no IDE**

**IntelliJ IDEA:**
- File → Open → Selecionar pasta do projeto
- Maven irá configurar automaticamente

**Eclipse:**
- File → Import → Maven → Existing Maven Projects
- Selecionar pasta do projeto

4. **Execute a aplicação**

**Via IDE:**
- Executar a classe `TadalafarmaApplication.java`

**Via Maven:**
```bash
mvn spring-boot:run
```

A aplicação estará disponível em `http://localhost:8081`

## Estrutura do Projeto

### Organização de Diretórios

```
src/
├── main/
│   ├── java/com/tadalafarma/Tadalafarma/
│   │   ├── config/          # Configurações (@Configuration)
│   │   ├── controller/      # Controllers MVC (@Controller)
│   │   ├── model/           # Entidades do domínio (@Document)
│   │   ├── repository/      # Repositórios MongoDB (extend MongoRepository)
│   │   ├── service/         # Lógica de negócio (@Service)
│   │   └── TadalafarmaApplication.java
│   └── resources/
│       ├── static/          # Arquivos estáticos (CSS, imagens)
│       ├── templates/       # Templates Thymeleaf (.html)
│       └── application.properties
└── test/
    └── java/com/tadalafarma/Tadalafarma/
        ├── controller/      # Testes de controllers
        ├── model/           # Testes de models
        └── service/         # Testes de services
```

### Convenções de Nomenclatura

#### Classes e Interfaces
- **Controllers**: Sufixo `Controller` (ex: `ClienteController`)
- **Services**: Sufixo `Service` (ex: `ClienteService`)
- **Repositories**: Sufixo `Repository` (ex: `ClienteRepository`)
- **Models**: Nome da entidade no singular (ex: `Cliente`, `Pedido`)
- **Config**: Sufixo `Config` (ex: `SecurityConfig`)

#### Métodos
- **Controllers**: Nomes descritivos (ex: `listarProdutos`, `cadastrarCliente`)
- **Services**: Nomes de ação (ex: `buscarPorId`, `cadastrar`, `validarCpf`)
- **Repositories**: Seguir padrão Spring Data (ex: `findByEmail`, `existsByCpf`)

#### Variáveis
- **camelCase**: Variáveis locais e atributos (ex: `clienteLogado`, `produtoId`)
- **SCREAMING_SNAKE_CASE**: Constantes (ex: `UPLOAD_DIR`)

## Padrões de Código

### Padrão de Controller

```java
@Controller
public class MinhaController {
    
    @Autowired
    private MinhaService minhaService;
    
    // Verificação de sessão
    private Cliente verificarSessaoCliente(HttpSession session) {
        return (Cliente) session.getAttribute("clienteLogado");
    }
    
    // GET - Exibir formulário
    @GetMapping("/minha-rota")
    public String exibirFormulario(HttpSession session, Model model) {
        Cliente cliente = verificarSessaoCliente(session);
        if (cliente == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("cliente", cliente);
        return "minha-view";
    }
    
    // POST - Processar formulário
    @PostMapping("/minha-rota")
    public String processarFormulario(@RequestParam String parametro,
                                     HttpSession session, Model model) {
        Cliente cliente = verificarSessaoCliente(session);
        if (cliente == null) {
            return "redirect:/login";
        }
        
        String resultado = minhaService.processar(parametro);
        
        if (resultado.contains("sucesso")) {
            return "redirect:/minha-rota?sucesso=" + resultado;
        } else {
            model.addAttribute("erro", resultado);
            return "minha-view";
        }
    }
}
```

### Padrão de Service

```java
@Service
public class MinhaService {
    
    @Autowired
    private MinhaRepository minhaRepository;
    
    // Método de validação
    public boolean validarDados(String dados) {
        if (dados == null || dados.trim().isEmpty()) {
            return false;
        }
        // Lógica de validação
        return true;
    }
    
    // Método de negócio
    public String processarDados(String dados) {
        // Validação
        if (!validarDados(dados)) {
            return "Dados inválidos";
        }
        
        // Lógica de negócio
        try {
            MinhaEntidade entidade = new MinhaEntidade(dados);
            minhaRepository.save(entidade);
            return "Processado com sucesso";
        } catch (Exception e) {
            return "Erro ao processar: " + e.getMessage();
        }
    }
    
    // Método de busca
    public Optional<MinhaEntidade> buscarPorId(String id) {
        return minhaRepository.findById(id);
    }
}
```

### Padrão de Repository

```java
@Repository
public interface MinhaRepository extends MongoRepository<MinhaEntidade, String> {
    
    // Método de busca por campo único
    Optional<MinhaEntidade> findByEmail(String email);
    
    // Método de busca por ID sequencial
    Optional<MinhaEntidade> findBySequencialId(Long sequencialId);
    
    // Método de verificação de existência
    boolean existsByEmail(String email);
    
    // Método de busca com ordenação
    List<MinhaEntidade> findAllByOrderByDataCriacaoDesc();
    
    // Método de busca com paginação
    Page<MinhaEntidade> findByNomeContainingIgnoreCase(String nome, Pageable pageable);
}
```

### Padrão de Model

```java
@Document(collection = "minha_colecao")
public class MinhaEntidade {
    
    @Id
    private String id;
    
    @Indexed(unique = true)
    private String email;
    
    private String nome;
    private Boolean status = true;
    private LocalDateTime dataCriacao;
    
    // Construtor padrão
    public MinhaEntidade() {
        this.dataCriacao = LocalDateTime.now();
    }
    
    // Construtor com parâmetros
    public MinhaEntidade(String nome, String email) {
        this();
        this.nome = nome;
        this.email = email;
    }
    
    // Getters e Setters
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    // ... outros getters e setters
    
    // Métodos auxiliares
    public String getNomeCompleto() {
        return nome + " (" + email + ")";
    }
}
```

## Validações Comuns

### Validação de CPF

```java
public boolean validarCpf(String cpf) {
    if (cpf == null || cpf.length() != 11) {
        return false;
    }
    
    cpf = cpf.replaceAll("\\D", "");
    
    // Verificar se todos os dígitos são iguais
    if (cpf.matches("(\\d)\\1{10}")) {
        return false;
    }
    
    // Calcular dígitos verificadores
    // ... implementação do algoritmo
    return true;
}
```

### Validação de Email

```java
public boolean validarEmail(String email) {
    if (email == null || email.trim().isEmpty()) {
        return false;
    }
    String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
    Pattern pattern = Pattern.compile(emailRegex);
    return pattern.matcher(email).matches();
}
```

## Estrutura de Commits

### Padrão de Mensagem de Commit

```
Tipo: Descrição curta (máx. 50 caracteres)

Corpo opcional explicando o que e por que (se necessário)
```

### Tipos de Commit

- `feat`: Nova funcionalidade
- `fix`: Correção de bug
- `docs`: Documentação
- `style`: Formatação (não altera lógica)
- `refactor`: Refatoração
- `test`: Adição/correção de testes
- `chore`: Tarefas de manutenção

### Exemplos

```
feat: Adicionar validação de CPF no cadastro de cliente

fix: Corrigir cálculo de frete para CEPs do Rio de Janeiro

docs: Atualizar documentação da API

test: Adicionar testes para ClienteService

refactor: Extrair validação de email para método reutilizável
```

## Como Adicionar Nova Funcionalidade

### Passo a Passo

1. **Criar o Model** (se necessário)
   - Criar classe em `model/`
   - Adicionar anotações (`@Document`, `@Id`, `@Indexed`)
   - Implementar getters/setters
   - Adicionar métodos auxiliares

2. **Criar o Repository**
   - Criar interface em `repository/`
   - Estender `MongoRepository<Entidade, String>`
   - Adicionar métodos de consulta personalizados

3. **Criar o Service**
   - Criar classe em `service/`
   - Adicionar anotação `@Service`
   - Injetar dependências com `@Autowired`
   - Implementar lógica de negócio
   - Adicionar validações

4. **Criar o Controller**
   - Criar classe em `controller/`
   - Adicionar anotação `@Controller`
   - Injetar Services com `@Autowired`
   - Criar métodos GET e POST
   - Implementar validação de sessão

5. **Criar as Views**
   - Criar templates HTML em `resources/templates/`
   - Usar Thymeleaf para renderização
   - Adicionar formulários e validações

6. **Criar Testes**
   - Criar classe de teste em `test/`
   - Testar Service, Controller e Model
   - Usar Mockito para mocks
   - Garantir cobertura adequada

### Exemplo: Adicionar Funcionalidade de Cupom

1. **Model** - `Cupom.java`:
```java
@Document(collection = "cupons")
public class Cupom {
    @Id
    private String id;
    private String codigo;
    private BigDecimal desconto;
    // ...
}
```

2. **Repository** - `CupomRepository.java`:
```java
public interface CupomRepository extends MongoRepository<Cupom, String> {
    Optional<Cupom> findByCodigo(String codigo);
}
```

3. **Service** - `CupomService.java`:
```java
@Service
public class CupomService {
    @Autowired
    private CupomRepository cupomRepository;
    
    public BigDecimal aplicarCupom(String codigo, BigDecimal valor) {
        // Lógica de aplicação do cupom
    }
}
```

4. **Controller** - `CupomController.java`:
```java
@Controller
public class CupomController {
    @Autowired
    private CupomService cupomService;
    
    @PostMapping("/cupom/aplicar")
    public String aplicarCupom(@RequestParam String codigo, HttpSession session) {
        // Lógica do controller
    }
}
```

## Executar Testes

### Executar Todos os Testes

```bash
mvn test
```

### Executar Teste Específico

```bash
mvn test -Dtest=ClienteServiceTest
```

### Executar com Cobertura

```bash
mvn clean test jacoco:report
```

### Executar Testes em IDE

**IntelliJ IDEA:**
- Clicar com botão direito na classe de teste
- Selecionar "Run 'NomeDoTeste'"

**Eclipse:**
- Clicar com botão direito na classe de teste
- Selecionar "Run As" → "JUnit Test"

## Debug

### Debug em IDE

**IntelliJ IDEA:**
- Configurar breakpoint
- Clicar com botão direito no arquivo
- Selecionar "Debug 'NomeDoArquivo'"

**Eclipse:**
- Configurar breakpoint
- Clicar com botão direito no arquivo
- Selecionar "Debug As" → "Spring Boot App"

### Logs

Os logs são exibidos no console. Para mais detalhes, configurar `application.properties`:

```properties
logging.level.com.tadalafarma=DEBUG
logging.level.org.springframework.web=DEBUG
```

## Configurações Úteis

### Application Properties

```properties
# Server
server.port=8081

# MongoDB
spring.data.mongodb.uri=mongodb://localhost:27017/tadalafarma

# Thymeleaf
spring.thymeleaf.cache=false

# Upload
spring.servlet.multipart.max-file-size=10MB
spring.servlet.multipart.max-request-size=10MB

# Logs
logging.level.root=INFO
logging.level.com.tadalafarma=DEBUG
```

## Boas Práticas

### Código

1. **Validações**: Sempre validar dados de entrada nos Services
2. **Tratamento de Erros**: Usar try-catch e retornar mensagens claras
3. **Reutilização**: Extrair lógica comum para métodos reutilizáveis
4. **Nomenclatura**: Usar nomes descritivos e consistentes
5. **Comentários**: Adicionar comentários apenas quando necessário

### Testes

1. **Cobertura**: Buscar cobertura mínima de 70% nas classes de negócio
2. **Isolamento**: Usar mocks para isolar testes
3. **Nomenclatura**: Usar padrão `test[NomeDoMetodo]_[Cenario]_[ResultadoEsperado]`
4. **Organização**: Organizar testes em classes por componente

### Git

1. **Commits Atômicos**: Um commit por funcionalidade/correção
2. **Mensagens Claras**: Descrever o que e por que
3. **Branching**: Usar branches para features e correções
4. **Pull Requests**: Revisar código antes de mergear

## Troubleshooting

### Problema: MongoDB não conecta

**Solução:**
- Verificar se MongoDB está rodando: `mongod`
- Verificar URI em `application.properties`
- Verificar credenciais (se MongoDB Atlas)

### Problema: Porta 8081 já em uso

**Solução:**
```bash
# Windows
netstat -ano | findstr :8081
taskkill /PID <PID> /F

# Linux/Mac
lsof -ti:8081 | xargs kill
```

Ou alterar porta em `application.properties`:
```properties
server.port=8082
```

### Problema: Testes falhando

**Solução:**
- Verificar se MongoDB está acessível
- Verificar mocks nos testes
- Limpar e recompilar: `mvn clean test`

---

Para mais informações, consulte:
- [Documentação Spring Boot](https://spring.io/projects/spring-boot)
- [Documentação Spring Data MongoDB](https://spring.io/projects/spring-data-mongodb)
- [Documentação Thymeleaf](https://www.thymeleaf.org/)

