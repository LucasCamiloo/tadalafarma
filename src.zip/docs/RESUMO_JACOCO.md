# Resumo Rápido - JaCoCo

## ✅ Configuração Completa

O JaCoCo já está configurado no projeto! O plugin foi adicionado ao `pom.xml` com:

- **Versão**: 0.8.11
- **Limite mínimo de cobertura**: 60% por pacote, 70% por classe
- **Geração automática de relatório** após os testes

## 🚀 Como Usar (3 Passos)

### 1. Executar Testes com Cobertura

```bash
.\mvnw.cmd clean test jacoco:report
```

Ou se tiver Maven instalado:

```bash
mvn clean test jacoco:report
```

### 2. Abrir o Relatório

O relatório HTML será gerado em: `target/site/jacoco/index.html`

**Windows:**
```bash
start target\site\jacoco\index.html
```

**Mac/Linux:**
```bash
open target/site/jacoco/index.html
```

### 3. Analisar os Resultados

No relatório você verá:
- 🟢 **Verde** = Código totalmente coberto
- 🟡 **Amarelo** = Código parcialmente coberto  
- 🔴 **Vermelho** = Código não coberto

## 📊 Métricas que o JaCoCo Mede

1. **Instruction Coverage** - Instruções executadas
2. **Branch Coverage** - Ramos de decisão testados (if/else, switch)
3. **Line Coverage** - Linhas de código executadas
4. **Method Coverage** - Métodos executados
5. **Class Coverage** - Classes testadas

## 🎯 Metas do Projeto

- **Cobertura Geral**: > 70% (meta), > 60% (mínimo)
- **Services**: > 80% de linhas
- **Controllers**: > 70% de linhas
- **Models**: > 70% de linhas

## 📝 Comandos Úteis

```bash
# Executar testes e gerar relatório
.\mvnw.cmd clean test jacoco:report

# Apenas gerar relatório (sem executar testes novamente)
.\mvnw.cmd jacoco:report

# Verificar se cobertura atinge os limites mínimos
.\mvnw.cmd test jacoco:check

# Executar teste específico com cobertura
.\mvnw.cmd test -Dtest=PedidoServiceTest jacoco:report
```

## 🔍 Onde Está o Relatório?

Após executar os testes, o relatório estará em:

```
tadalafarma-main/
└── target/
    └── site/
        └── jacoco/
            └── index.html  ← Abra este arquivo no navegador
```

## 📚 Documentação Completa

Para mais detalhes, consulte: `docs/GUIA_JACOCO.md`

---

**Dica**: Execute os testes primeiro para gerar o relatório. Se não houver testes executados, o relatório não será gerado.

