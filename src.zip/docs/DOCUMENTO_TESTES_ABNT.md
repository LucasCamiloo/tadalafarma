# DOCUMENTO DE TESTES DE SOFTWARE
## Sistema Tadalafarma

---

**AUTOR:** [SEU NOME]  
**INSTITUIÇÃO:** [NOME DA INSTITUIÇÃO]  
**CURSO:** [NOME DO CURSO]  
**DISCIPLINA:** Testes de Software  
**DATA:** [MÊS/ANO]

---

## SUMÁRIO

1. [INTRODUÇÃO](#1-introdução)
2. [REVISÃO BIBLIOGRÁFICA](#2-revisão-bibliográfica)
3. [METODOLOGIA](#3-metodologia)
4. [ANÁLISE DO SISTEMA](#4-análise-do-sistema)
5. [PLANO DE TESTES](#5-plano-de-testes)
6. [TESTES IMPLEMENTADOS](#6-testes-implementados)
7. [RESULTADOS E ANÁLISE](#7-resultados-e-análise)
8. [CONCLUSÃO](#8-conclusão)
9. [REFERÊNCIAS](#referências)
10. [ANEXOS](#anexos)

---

## LISTA DE TABELAS

- Tabela 1: Matriz de Cobertura de Testes
- Tabela 2: Cenários de Teste por Componente
- Tabela 3: Métricas de Cobertura Esperadas
- [PLACEHOLDER: Adicionar outras tabelas conforme necessário]

---

## LISTA DE ABREVIATURAS E SIGLAS

- **ABNT**: Associação Brasileira de Normas Técnicas
- **API**: Application Programming Interface
- **CRUD**: Create, Read, Update, Delete
- **HTTP**: Hypertext Transfer Protocol
- **IDE**: Integrated Development Environment
- **JSON**: JavaScript Object Notation
- **MVC**: Model-View-Controller
- **REST**: Representational State Transfer
- **UUID**: Universally Unique Identifier
- [PLACEHOLDER: Adicionar outras abreviações conforme necessário]

---

## 1. INTRODUÇÃO

O presente documento apresenta uma análise completa da estratégia de testes implementada no sistema **Tadalafarma**, uma aplicação web de e-commerce para farmácia desenvolvida em Spring Boot. Este trabalho foi desenvolvido no contexto da disciplina de Testes de Software, com o objetivo de documentar os planos de teste, a implementação dos testes e os resultados obtidos.

O Tadalafarma é um sistema completo que permite a gestão de produtos, pedidos, clientes e usuários do backoffice, utilizando arquitetura em camadas e integração com MongoDB como banco de dados NoSQL. A aplicação oferece funcionalidades tanto para clientes finais (loja virtual, carrinho de compras, checkout) quanto para administradores e estoquistas (gestão de produtos, pedidos e usuários).

A importância dos testes de software neste contexto é fundamental para garantir a qualidade, confiabilidade e manutenibilidade do sistema. Através de uma estratégia bem definida de testes, é possível identificar defeitos precocemente, reduzir custos de manutenção e aumentar a confiança no sistema.

Este documento está organizado da seguinte forma: a Seção 2 apresenta uma revisão bibliográfica sobre conceitos de testes de software; a Seção 3 descreve a metodologia e estratégia de testes adotada; a Seção 4 apresenta uma análise da arquitetura do sistema; a Seção 5 detalha o plano de testes; a Seção 6 descreve os testes implementados; a Seção 7 apresenta os resultados e análise; e finalmente, a Seção 8 conclui o trabalho.

[PLACEHOLDER: Adicionar mais contexto sobre o projeto, objetivos específicos do documento, ou justificativa da escolha do sistema]

---

## 2. REVISÃO BIBLIOGRÁFICA

[PLACEHOLDER: Esta seção deve conter uma revisão bibliográfica sobre conceitos fundamentais de testes de software. Sugestões de tópicos a incluir:]

### 2.1 Conceitos Fundamentais de Testes de Software

[PLACEHOLDER: Discutir conceitos como:]
- Definição de testes de software
- Objetivos dos testes
- Princípios fundamentais (ex: teste mostra a presença de defeitos, teste exaustivo é impossível, etc.)
- Níveis de teste (unitário, integração, sistema, aceitação)

### 2.2 Tipos de Testes

[PLACEHOLDER: Discutir diferentes tipos de testes:]
- Testes funcionais vs. não-funcionais
- Testes de caixa branca vs. caixa preta
- Testes estruturais vs. comportamentais

### 2.3 Frameworks e Ferramentas de Teste

[PLACEHOLDER: Discutir frameworks utilizados no projeto:]
- JUnit 5: framework de testes unitários para Java
- Mockito: framework para criação de mocks e stubs
- Spring Boot Test: suporte para testes de integração
- JaCoCo: ferramenta de análise de cobertura de código

### 2.4 Cobertura de Código

[PLACEHOLDER: Discutir métricas de cobertura:]
- Cobertura de linhas
- Cobertura de branches (ramos)
- Cobertura de métodos
- Cobertura de classes
- Metas de cobertura recomendadas

[PLACEHOLDER: Adicionar citações bibliográficas conforme normas ABNT]

---

## 3. METODOLOGIA

Esta seção descreve a metodologia e estratégia de testes adotada no projeto Tadalafarma, incluindo os frameworks utilizados, tipos de testes implementados e padrões seguidos.

### 3.1 Estratégia de Testes

O projeto Tadalafarma utiliza uma estratégia de testes em camadas, focada em garantir a qualidade e confiabilidade do código através de testes unitários e de integração. A estratégia segue o princípio da pirâmide de testes, priorizando testes unitários na base, seguidos por testes de integração e, quando necessário, testes end-to-end.

A estratégia de testes é organizada por camadas da arquitetura:

1. **Camada de Modelo (Models)**: Testes de lógica de negócio encapsulada nas entidades
2. **Camada de Serviço (Services)**: Testes unitários da lógica de negócio com mocks de dependências
3. **Camada de Controle (Controllers)**: Testes de integração das rotas e validações de entrada

### 3.2 Frameworks e Tecnologias Utilizadas

O projeto utiliza as seguintes tecnologias para testes:

#### 3.2.1 JUnit 5

JUnit 5 é o framework de testes unitários padrão para Java. Ele fornece anotações como `@Test`, `@BeforeEach`, `@AfterEach`, e assertions para verificação de resultados esperados.

#### 3.2.2 Mockito

Mockito é utilizado para criar mocks de dependências, permitindo isolar unidades de código durante os testes. As principais anotações utilizadas são:
- `@Mock`: Cria um mock de uma dependência
- `@InjectMocks`: Injeta mocks em uma instância da classe sob teste
- `@ExtendWith(MockitoExtension.class)`: Configura o ambiente Mockito

#### 3.2.3 Spring Boot Test

Spring Boot Test fornece suporte para testes de integração, incluindo:
- `@WebMvcTest`: Para testes de controllers MVC
- `@SpringBootTest`: Para testes de integração completos
- `MockMvc`: Para simular requisições HTTP

#### 3.2.4 JaCoCo

JaCoCo é utilizado para análise de cobertura de código, gerando relatórios detalhados sobre a porcentagem de código testado.

### 3.3 Tipos de Testes Implementados

#### 3.3.1 Testes Unitários

**Objetivo**: Testar unidades isoladas de código (métodos, classes).

**Características**:
- Testam lógica de negócio isoladamente
- Usam mocks para dependências externas
- Execução rápida
- Não requerem contexto Spring completo

**Exemplo**: Testes de Services com repositories mockados.

#### 3.3.2 Testes de Integração

**Objetivo**: Testar integração entre componentes.

**Características**:
- Testam interação entre camadas
- Usam contexto Spring
- Podem acessar banco de dados de teste
- Execução mais lenta que testes unitários

**Exemplo**: Testes de Controllers com MockMvc.

#### 3.3.3 Testes de Modelos

**Objetivo**: Testar lógica e métodos auxiliares das entidades.

**Características**:
- Testam métodos de negócio dos models
- Validações e transformações
- Métodos auxiliares

**Exemplo**: Testes de validação e formatação em classes de modelo.

### 3.4 Padrões de Teste

#### 3.4.1 Padrão AAA (Arrange-Act-Assert)

Todos os testes seguem o padrão AAA:

```java
@Test
void testNomeDoMetodo_Cenario_ResultadoEsperado() {
    // Arrange - Preparar dados e mocks
    String cpf = "11144477735";
    when(repository.existsByCpf(cpf)).thenReturn(false);
    
    // Act - Executar ação
    boolean resultado = service.cpfJaExiste(cpf);
    
    // Assert - Verificar resultado
    assertFalse(resultado);
    verify(repository, times(1)).existsByCpf(cpf);
}
```

#### 3.4.2 Nomenclatura de Testes

**Padrão**: `test[NomeDoMetodo]_[Cenario]_[ResultadoEsperado]`

**Exemplos**:
- `testValidarCpf_ComCpfValido_DeveRetornarTrue()`
- `testAutenticar_ComCredenciaisInvalidas_DeveRetornarNull()`
- `testCadastrarCliente_ComDadosValidos_DeveRetornarSucesso()`

### 3.5 Estrutura de Organização

Os testes estão organizados na mesma estrutura de pacotes do código de produção:

```
src/test/java/com/tadalafarma/Tadalafarma/
├── controller/      # Testes de controllers
├── model/          # Testes de models
└── service/         # Testes de services
```

[PLACEHOLDER: Adicionar mais detalhes sobre metodologia, se necessário]

---

## 4. ANÁLISE DO SISTEMA

Esta seção apresenta uma análise da arquitetura e componentes principais do sistema Tadalafarma, fornecendo contexto necessário para compreender os testes implementados.

### 4.1 Visão Geral do Sistema

O Tadalafarma é uma aplicação web baseada em **Spring Boot 3.5.6** que segue a arquitetura em camadas (Layered Architecture), separando responsabilidades em diferentes níveis da aplicação. O sistema utiliza **MongoDB** como banco de dados NoSQL e **Thymeleaf** como template engine para renderização de views HTML.

### 4.2 Arquitetura em Camadas

O sistema está organizado em quatro camadas principais:

#### 4.2.1 Camada de Apresentação (Controllers)

**Responsabilidades**:
- Receber requisições HTTP
- Validar dados de entrada
- Chamar a camada de serviço
- Retornar respostas (views HTML ou JSON)
- Gerenciar sessões HTTP

**Componentes Principais**:
- `BackofficeController`: Gestão do backoffice (pedidos, usuários)
- `ClienteController`: Gestão de clientes e checkout
- `LoginController`: Autenticação do backoffice
- `LojaController`: Interface pública da loja (produtos, carrinho)
- `ProdutoController`: Gestão de produtos (CRUD)

#### 4.2.2 Camada de Negócio (Services)

**Responsabilidades**:
- Implementar lógica de negócio
- Validações de dados
- Regras de negócio complexas
- Orquestração entre repositories
- Integrações externas

**Componentes Principais**:
- `ClienteService`: Validações (CPF, email, nome), autenticação, CRUD de clientes
- `PedidoService`: Gestão de pedidos, validações de carrinho e pagamento
- `ProdutoService`: CRUD de produtos, gerenciamento de imagens
- `UsuarioService`: Autenticação e gestão de usuários do backoffice
- `ViaCepService`: Integração com API ViaCEP para busca de endereços

#### 4.2.3 Camada de Persistência (Repositories)

**Responsabilidades**:
- Abstração do acesso ao banco de dados
- Operações CRUD
- Consultas personalizadas
- Interface entre aplicação e MongoDB

**Componentes Principais**:
- `ClienteRepository`
- `PedidoRepository`
- `ProdutoRepository`
- `ProdutoImagemRepository`
- `UsuarioRepository`

#### 4.2.4 Camada de Domínio (Models)

**Responsabilidades**:
- Representar entidades do negócio
- Encapsular dados e comportamentos
- Validações básicas
- Métodos auxiliares de negócio

**Entidades Principais**:
- `Cliente`: Dados pessoais, endereços, status
- `Produto`: Dados do produto, estoque, avaliação
- `Pedido`: Itens, endereço de entrega, forma de pagamento, status
- `Usuario`: Dados do usuário do backoffice, grupo, status
- `Endereco`: Dados completos do endereço
- `ItemPedido`: Item individual de um pedido
- `ProdutoImagem`: Referências de imagens de produtos

### 4.3 Fluxo de Dados Típico

```
1. Cliente → Requisição HTTP
2. Controller → Recebe requisição
3. Controller → Valida sessão/autenticação
4. Controller → Chama Service
5. Service → Executa lógica de negócio
6. Service → Chama Repository (se necessário)
7. Repository → Acessa MongoDB
8. Repository → Retorna dados
9. Service → Processa e retorna resultado
10. Controller → Prepara modelo para view
11. Thymeleaf → Renderiza HTML
12. Controller → Retorna resposta HTTP
```

### 4.4 Autenticação e Autorização

O sistema utiliza autenticação baseada em sessão HTTP, com armazenamento na sessão do servidor. As senhas são criptografadas com BCrypt. O controle de acesso é realizado manualmente através de verificação de sessão nos controllers.

**Grupos de Usuários**:
- **ADMINISTRADOR**: Acesso completo ao sistema
- **ESTOQUISTA**: Pode gerenciar pedidos e estoque
- **CLIENTE**: Acesso à loja e área do cliente

### 4.5 Integrações Externas

#### 4.5.1 Integração com ViaCEP

O sistema integra com a API ViaCEP para busca automática de endereços por CEP, facilitando o cadastro de clientes e endereços de entrega.

#### 4.5.2 MongoDB

O sistema utiliza MongoDB como banco de dados NoSQL, armazenando documentos em coleções. Índices únicos são utilizados para campos como email, CPF e IDs sequenciais.

[PLACEHOLDER: Adicionar mais detalhes sobre arquitetura, se necessário]

---

## 5. PLANO DE TESTES

Esta seção apresenta o plano detalhado de testes para o projeto Tadalafarma, incluindo matriz de cobertura, cenários de teste detalhados por componente e estratégia de implementação.

### 5.1 Matriz de Cobertura

A Tabela 1 apresenta a matriz de cobertura de testes, mostrando o estado atual versus a meta de cobertura para cada componente do sistema.

**Tabela 1: Matriz de Cobertura de Testes**

| Componente | Estado Atual | Meta | Status |
|------------|--------------|------|--------|
| **PedidoService** | ✅ 100% | 100% | Completo |
| **ClienteService** | ❌ 0% | 80%+ | Pendente |
| **ProdutoService** | ❌ 0% | 80%+ | Pendente |
| **UsuarioService** | ❌ 0% | 80%+ | Pendente |
| **ViaCepService** | ❌ 0% | 70%+ | Pendente |
| **BackofficeController** | ✅ 70% | 80%+ | Parcial |
| **ClienteController** | ⚠️ 20% | 80%+ | Parcial |
| **LojaController** | ⚠️ 15% | 80%+ | Parcial |
| **LoginController** | ❌ 0% | 80%+ | Pendente |
| **ProdutoController** | ❌ 0% | 80%+ | Pendente |
| **Pedido (Model)** | ✅ 90% | 90%+ | Completo |
| **Cliente (Model)** | ❌ 0% | 70%+ | Pendente |
| **Endereco (Model)** | ❌ 0% | 70%+ | Pendente |
| **ItemPedido (Model)** | ❌ 0% | 70%+ | Pendente |
| **Produto (Model)** | ❌ 0% | 70%+ | Pendente |
| **ProdutoImagem (Model)** | ❌ 0% | 70%+ | Pendente |
| **Usuario (Model)** | ❌ 0% | 70%+ | Pendente |

**Cobertura Geral Atual**: ~15%  
**Cobertura Geral Meta**: > 70%

### 5.2 Planos de Testes por Componente

#### 5.2.1 ClienteServiceTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/ClienteServiceTest.java`

**Cenários de Validação de CPF** (5 cenários):
1. `testValidarCpf_ComCpfValido_DeveRetornarTrue` - CPF válido (11144477735)
2. `testValidarCpf_ComCpfInvalido_DeveRetornarFalse` - CPF inválido (12345678901)
3. `testValidarCpf_ComCpfFormatado_DeveRetornarTrue` - CPF com formatação (111.444.777-35)
4. `testValidarCpf_ComCpfTamanhoIncorreto_DeveRetornarFalse` - CPF com tamanho incorreto
5. `testValidarCpf_ComCpfTodosDigitosIguais_DeveRetornarFalse` - CPF: 11111111111

**Cenários de Validação de Email** (4 cenários):
6. `testValidarEmail_ComEmailValido_DeveRetornarTrue` - Email: teste@exemplo.com
7. `testValidarEmail_ComEmailInvalido_DeveRetornarFalse` - Email: email-invalido
8. `testValidarEmail_ComEmailNull_DeveRetornarFalse` - Email: null
9. `testValidarEmail_ComEmailVazio_DeveRetornarFalse` - Email: ""

**Cenários de Validação de Nome** (4 cenários):
10. `testValidarNome_ComNomeValido_DeveRetornarTrue` - Nome: "João Silva"
11. `testValidarNome_ComApenasUmNome_DeveRetornarFalse` - Nome: "João"
12. `testValidarNome_ComPalavraMenorQueTresLetras_DeveRetornarFalse` - Nome: "João Ab"
13. `testValidarNome_ComNomeNull_DeveRetornarFalse` - Nome: null

**Cenários de Validação de Data de Nascimento** (3 cenários):
14. `testValidarDataNascimento_ComDataValida_DeveRetornarLocalDate` - Data: "1990-01-15"
15. `testValidarDataNascimento_ComDataFutura_DeveRetornarNull` - Data futura
16. `testValidarDataNascimento_ComFormatoInvalido_DeveRetornarNull` - Data: "15/01/1990"

**Cenários de Validação de Gênero** (2 cenários):
17. `testValidarGenero_ComGeneroValido_DeveRetornarTrue` - Gêneros: "masculino", "feminino", "outro", "não informado"
18. `testValidarGenero_ComGeneroInvalido_DeveRetornarFalse` - Gênero: "invalido"

**Cenários de Autenticação** (4 cenários):
19. `testAutenticar_ComCredenciaisValidas_DeveRetornarCliente` - Email e senha corretos
20. `testAutenticar_ComSenhaIncorreta_DeveRetornarNull` - Senha incorreta
21. `testAutenticar_ComClienteInativo_DeveRetornarNull` - Cliente com status false
22. `testAutenticar_ComEmailNaoExiste_DeveRetornarNull` - Email não cadastrado

**Cenários de Cadastro** (4 cenários):
23. `testCadastrarCliente_ComDadosValidos_DeveRetornarSucesso` - Todos os dados válidos
24. `testCadastrarCliente_ComCpfDuplicado_DeveRetornarErro` - CPF já cadastrado
25. `testCadastrarCliente_ComEmailDuplicado_DeveRetornarErro` - Email já cadastrado
26. `testCadastrarCliente_ComSenhasNaoConferem_DeveRetornarErro` - Senhas diferentes

**Cenários de Alteração** (2 cenários):
27. `testAlterarDadosCliente_ComDadosValidos_DeveRetornarSucesso` - Dados válidos
28. `testAlterarSenhaCliente_ComDadosValidos_DeveRetornarSucesso` - Senha válida

**Cenários de Endereços** (2 cenários):
29. `testAdicionarEnderecoEntrega_ComDadosValidos_DeveRetornarSucesso` - Endereço válido
30. `testAlterarEnderecoPadrao_ComEnderecoValido_DeveRetornarSucesso` - Endereço válido

**Total de Cenários**: 30

#### 5.2.2 ProdutoServiceTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/ProdutoServiceTest.java`

**Cenários de Cadastro** (6 cenários):
1. `testCadastrarProduto_ComDadosValidos_DeveRetornarSucesso` - Todos os dados válidos
2. `testCadastrarProduto_ComNomeVazio_DeveRetornarErro` - Nome vazio
3. `testCadastrarProduto_ComNomeMaiorQue200Caracteres_DeveRetornarErro` - Nome > 200 caracteres
4. `testCadastrarProduto_ComAvaliacaoInvalida_DeveRetornarErro` - Avaliação < 1 ou > 5
5. `testCadastrarProduto_ComPrecoZero_DeveRetornarErro` - Preço = 0
6. `testCadastrarProduto_ComEstoqueNegativo_DeveRetornarErro` - Estoque < 0

**Cenários de Alteração** (3 cenários):
7. `testAlterarProduto_ComDadosValidos_DeveRetornarSucesso` - Dados válidos
8. `testAlterarProduto_ComProdutoNaoExiste_DeveRetornarErro` - Produto não encontrado
9. `testAlterarQuantidadeEstoque_ComQuantidadeValida_DeveRetornarSucesso` - Quantidade válida

**Cenários de Status** (2 cenários):
10. `testAlterarStatus_ComProdutoAtivo_DeveDesativar` - Produto ativo
11. `testAlterarStatus_ComProdutoInativo_DeveAtivar` - Produto inativo

**Cenários de Listagem** (3 cenários):
12. `testListarProdutos_ComBusca_DeveRetornarProdutosFiltrados` - Busca por nome
13. `testListarProdutos_SemBusca_DeveRetornarTodosProdutos` - Sem busca
14. `testListarProdutos_ComPaginacao_DeveRetornarPaginaCorreta` - Paginação

**Cenários de Imagens** (4 cenários):
15. `testSalvarImagem_ComArquivoValido_DeveRetornarSucesso` - Arquivo válido
16. `testSalvarImagem_ComArquivoVazio_DeveRetornarErro` - Arquivo vazio
17. `testDefinirImagemPrincipal_ComImagemValida_DeveRetornarSucesso` - Imagem válida
18. `testDeletarImagem_ComImagemValida_DeveRetornarSucesso` - Imagem válida

**Total de Cenários**: 18

#### 5.2.3 UsuarioServiceTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/UsuarioServiceTest.java`

**Cenários de Validação** (4 cenários):
1. `testValidarCpf_ComCpfValido_DeveRetornarTrue`
2. `testValidarCpf_ComCpfInvalido_DeveRetornarFalse`
3. `testValidarEmail_ComEmailValido_DeveRetornarTrue`
4. `testValidarEmail_ComEmailInvalido_DeveRetornarFalse`

**Cenários de Autenticação** (4 cenários):
5. `testAutenticar_ComCredenciaisValidas_DeveRetornarUsuario`
6. `testAutenticar_ComSenhaIncorreta_DeveRetornarNull`
7. `testAutenticar_ComUsuarioInativo_DeveRetornarNull`
8. `testAutenticar_ComEmailNaoExiste_DeveRetornarNull`

**Cenários de Cadastro** (4 cenários):
9. `testCadastrarUsuario_ComDadosValidos_DeveRetornarSucesso`
10. `testCadastrarUsuario_ComCpfDuplicado_DeveRetornarErro`
11. `testCadastrarUsuario_ComEmailDuplicado_DeveRetornarErro`
12. `testCadastrarUsuario_ComGrupoInvalido_DeveRetornarErro`

**Cenários de Alteração** (4 cenários):
13. `testAlterarUsuario_ComDadosValidos_DeveRetornarSucesso`
14. `testAlterarSenha_ComDadosValidos_DeveRetornarSucesso`
15. `testAlterarStatus_ComUsuarioAtivo_DeveDesativar`
16. `testAlterarStatus_ComUsuarioInativo_DeveAtivar`

**Cenários de Listagem** (2 cenários):
17. `testListarTodos_DeveRetornarTodosUsuarios`
18. `testListarTodos_ComUsuariosSemSequencialId_DeveGerarIds`

**Total de Cenários**: 18

#### 5.2.4 ViaCepServiceTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/ViaCepServiceTest.java`

**Cenários de Busca** (7 cenários):
1. `testBuscarEnderecoPorCep_ComCepValido_DeveRetornarEndereco` - CEP válido (mockar API)
2. `testBuscarEnderecoPorCep_ComCepInvalido_DeveRetornarNull` - CEP inválido
3. `testBuscarEnderecoPorCep_ComCepFormatado_DeveProcessarCorretamente` - CEP: "01310-100"
4. `testBuscarEnderecoPorCep_ComCepSemFormatacao_DeveProcessarCorretamente` - CEP: "01310100"
5. `testBuscarEnderecoPorCep_ComCepInexistente_DeveRetornarNull` - CEP não encontrado (mockar erro)
6. `testValidarCep_ComCepValido_DeveRetornarTrue` - CEP válido
7. `testValidarCep_ComCepInvalido_DeveRetornarFalse` - CEP inválido

**Total de Cenários**: 7

#### 5.2.5 LoginControllerTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/LoginControllerTest.java`

**Cenários** (6 cenários):
1. `testIndex_DeveRedirecionarParaLoja` - GET /
2. `testLogin_Get_DeveRetornarFormulario` - GET /backoffice/login
3. `testLogin_Post_ComCredenciaisValidas_DeveRedirecionarParaBackoffice` - POST com credenciais válidas
4. `testLogin_Post_ComCredenciaisInvalidas_DeveRetornarErro` - POST com credenciais inválidas
5. `testLogin_Post_ComUsuarioInativo_DeveRetornarErro` - POST com usuário inativo
6. `testLogout_DeveInvalidarSessaoERedirecionar` - GET /backoffice/logout

**Total de Cenários**: 6

#### 5.2.6 ProdutoControllerTest

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/ProdutoControllerTest.java`

**Cenários** (10+ cenários):
1. `testListarProdutos_ComUsuarioLogado_DeveRetornarLista`
2. `testListarProdutos_SemUsuarioLogado_DeveRedirecionarParaLogin`
3. `testCadastrarProduto_Get_ComAdmin_DeveRetornarFormulario`
4. `testCadastrarProduto_Get_ComEstoquista_DeveNegarAcesso`
5. `testCadastrarProduto_Post_ComDadosValidos_DeveRedirecionarParaLista`
6. `testAlterarProduto_Get_ComProdutoExistente_DeveRetornarFormulario`
7. `testAlterarProduto_Post_ComAdmin_DevePermitirAlteracaoCompleta`
8. `testAlterarProduto_Post_ComEstoquista_DevePermitirApenasQuantidade`
9. `testVisualizarProduto_ComAdmin_DeveRetornarVisualizacao`
10. `testAlterarStatus_ComAdmin_DeveAlterarStatus`

**Total de Cenários**: 10+

#### 5.2.7 Testes de Models

**ClienteTest** (4 cenários):
1. `testAdicionarEnderecoEntrega_DeveAdicionarNaLista`
2. `testGetEnderecoPadraoEntrega_ComEnderecoPadrao_DeveRetornarEnderecoPadrao`
3. `testGetEnderecoPadraoEntrega_SemEnderecoPadrao_DeveRetornarPrimeiro`
4. `testDefinirEnderecoPadrao_DeveAlterarFlagPadrao`

**EnderecoTest** (2 cenários):
1. `testGetEnderecoCompleto_DeveRetornarEnderecoFormatado`
2. `testConstrutor_ComParametros_DeveInicializarCorretamente`

**ItemPedidoTest** (2 cenários):
1. `testConstrutor_ComParametros_DeveInicializarCorretamente`
2. `testCalculoTotal_DeveSerPrecoUnitarioVezesQuantidade`

**ProdutoTest** (2 cenários):
1. `testConstrutor_ComParametros_DeveInicializarCorretamente`
2. `testConstrutor_DeveInicializarDatas`

**ProdutoImagemTest** (2 cenários):
1. `testConstrutor_ComParametros_DeveInicializarCorretamente`
2. `testConstrutor_DeveInicializarDataUpload`

**UsuarioTest** (2 cenários):
1. `testConstrutor_ComParametros_DeveInicializarGrupoCorretamente`
2. `testSetGrupo_ComEnum_DeveSalvarComoString`

### 5.3 Estratégia de Implementação

A estratégia de implementação foi dividida em três prioridades:

#### Prioridade 1 (Crítico) - Autenticação e Validações
1. **ClienteServiceTest** - Validações críticas de CPF, email, nome
2. **UsuarioServiceTest** - Autenticação do backoffice
3. **LoginControllerTest** - Controle de acesso

**Prazo Estimado**: 1-2 dias

#### Prioridade 2 (Importante) - Gestão de Dados
4. **ProdutoServiceTest** - Gestão de produtos e estoque
5. **ProdutoControllerTest** - Interface de gestão

**Prazo Estimado**: 1-2 dias

#### Prioridade 3 (Complementar) - Integrações e Models
6. **ViaCepServiceTest** - Integração externa
7. **Testes de Models** - Lógica de negócio das entidades

**Prazo Estimado**: 1 dia

**Prazo Total Estimado**: 3-5 dias

### 5.4 Métricas de Cobertura Esperadas

**Tabela 3: Métricas de Cobertura Esperadas**

| Componente | Linhas | Branches | Métodos | Classes |
|------------|--------|----------|---------|---------|
| Services | > 80% | > 75% | > 85% | 100% |
| Controllers | > 70% | > 65% | > 80% | 100% |
| Models | > 70% | > 65% | > 80% | 100% |

**Cobertura Geral**:
- **Meta**: > 70% de cobertura geral
- **Mínimo Aceitável**: > 60% de cobertura geral
- **Ideal**: > 80% de cobertura geral

[PLACEHOLDER: Adicionar mais detalhes sobre estratégia de testes, se necessário]

---

## 6. TESTES IMPLEMENTADOS

Esta seção apresenta uma descrição detalhada dos testes implementados no projeto, organizados por camada da arquitetura.

### 6.1 Testes de Services

#### 6.1.1 PedidoServiceTest

**Status**: ✅ Completo (100% de cobertura)

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/service/PedidoServiceTest.java`

**Descrição**: Este teste cobre completamente a classe `PedidoService`, testando as principais funcionalidades de gestão de pedidos.

**Testes Implementados**:

1. **testBuscarTodosPedidos_DeveRetornarListaOrdenadaPorDataDecrescente**
   - **Objetivo**: Verificar se o método retorna todos os pedidos ordenados por data de criação decrescente
   - **Cenário**: Lista com múltiplos pedidos
   - **Resultado Esperado**: Lista ordenada corretamente (mais recente primeiro)

2. **testBuscarTodosPedidos_QuandoNaoHaPedidos_DeveRetornarListaVazia**
   - **Objetivo**: Verificar comportamento quando não há pedidos cadastrados
   - **Cenário**: Repositório retorna lista vazia
   - **Resultado Esperado**: Lista vazia retornada

3. **testAtualizarStatusPedido_ComStatusValido_DeveAtualizarComSucesso**
   - **Objetivo**: Verificar atualização de status com status válido
   - **Cenário**: Pedido existe e status é válido
   - **Resultado Esperado**: Status atualizado com sucesso

4. **testAtualizarStatusPedido_ComTodosStatusValidos_DeveAtualizarComSucesso**
   - **Objetivo**: Verificar que todos os status válidos são aceitos
   - **Cenário**: Testa todos os status: AGUARDANDO_PAGAMENTO, PAGAMENTO_REJEITADO, PAGAMENTO_COM_SUCESSO, AGUARDANDO_RETIRADA, EM_TRANSITO, ENTREGUE
   - **Resultado Esperado**: Todos os status são atualizados com sucesso

5. **testAtualizarStatusPedido_QuandoPedidoNaoExiste_DeveRetornarErro**
   - **Objetivo**: Verificar tratamento de erro quando pedido não existe
   - **Cenário**: ID do pedido não encontrado no repositório
   - **Resultado Esperado**: Mensagem de erro "Pedido não encontrado"

6. **testAtualizarStatusPedido_ComStatusInvalido_DeveRetornarErro**
   - **Objetivo**: Verificar validação de status inválido
   - **Cenário**: Status não está na lista de status válidos
   - **Resultado Esperado**: Mensagem de erro "Status inválido"

7. **testAtualizarStatusPedido_ComStatusNull_DeveRetornarErro**
   - **Objetivo**: Verificar tratamento de status nulo
   - **Cenário**: Status é null
   - **Resultado Esperado**: Mensagem de erro "Status inválido"

8. **testAtualizarStatusPedido_QuandoOcorreErroAoSalvar_DeveRetornarMensagemDeErro**
   - **Objetivo**: Verificar tratamento de exceções ao salvar
   - **Cenário**: Exceção lançada ao salvar no repositório
   - **Resultado Esperado**: Mensagem de erro contendo "Erro ao atualizar status"

**Estrutura do Teste**:
```java
@ExtendWith(MockitoExtension.class)
class PedidoServiceTest {
    @Mock
    private PedidoRepository pedidoRepository;
    
    @InjectMocks
    private PedidoService pedidoService;
    
    // Fixtures criadas em @BeforeEach
    // Testes seguem padrão AAA
}
```

#### 6.1.2 Outros Services

[PLACEHOLDER: Descrever testes de outros services quando implementados:
- ClienteServiceTest
- ProdutoServiceTest
- UsuarioServiceTest
- ViaCepServiceTest]

### 6.2 Testes de Controllers

#### 6.2.1 BackofficeControllerTest

**Status**: ✅ Parcial (70% de cobertura)

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/BackofficeControllerTest.java`

**Descrição**: Testes dos endpoints relacionados à gestão de pedidos no backoffice.

**Testes Implementados**:
- Testes de listagem de pedidos
- Testes de edição de pedido
- Testes de atualização de status

[PLACEHOLDER: Adicionar detalhes específicos dos testes implementados]

#### 6.2.2 ClienteControllerTest

**Status**: ⚠️ Parcial (20% de cobertura)

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/ClienteControllerTest.java`

**Descrição**: Testes dos endpoints da área do cliente.

**Testes Implementados**:
- Testes de visualização de detalhes do pedido
- Verificações de autenticação e propriedade

[PLACEHOLDER: Adicionar detalhes específicos dos testes implementados]

#### 6.2.3 LojaControllerTest

**Status**: ⚠️ Parcial (15% de cobertura)

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/controller/LojaControllerTest.java`

**Descrição**: Testes dos endpoints da loja pública.

**Testes Implementados**:
- Testes de cálculo de frete por CEP
- Validação de CEP

[PLACEHOLDER: Adicionar detalhes específicos dos testes implementados]

#### 6.2.4 Outros Controllers

[PLACEHOLDER: Descrever testes de outros controllers quando implementados:
- LoginControllerTest
- ProdutoControllerTest]

### 6.3 Testes de Models

#### 6.3.1 PedidoTest

**Status**: ✅ Completo (90% de cobertura)

**Arquivo**: `src/test/java/com/tadalafarma/Tadalafarma/model/PedidoTest.java`

**Descrição**: Testes da entidade Pedido, incluindo métodos de negócio.

**Testes Implementados**:
- Testes de adicionar itens ao pedido
- Testes de status e formatação
- Testes de dados do cartão

[PLACEHOLDER: Adicionar detalhes específicos dos testes implementados]

#### 6.3.2 Outros Models

[PLACEHOLDER: Descrever testes de outros models quando implementados:
- ClienteTest
- EnderecoTest
- ItemPedidoTest
- ProdutoTest
- ProdutoImagemTest
- UsuarioTest]

### 6.4 Exemplo de Teste Detalhado

A seguir, apresenta-se um exemplo completo de teste implementado:

**Exemplo: testBuscarTodosPedidos_DeveRetornarListaOrdenadaPorDataDecrescente**

```java
@Test
void testBuscarTodosPedidos_DeveRetornarListaOrdenadaPorDataDecrescente() {
    // Arrange - Preparar dados e mocks
    List<Pedido> pedidos = Arrays.asList(pedido2, pedido1); 
    // Ordenado por data decrescente (mais recente primeiro)
    when(pedidoRepository.findAllByOrderByDataCriacaoDesc())
        .thenReturn(pedidos);

    // Act - Executar ação
    List<Pedido> resultado = pedidoService.buscarTodosPedidos();

    // Assert - Verificar resultado
    assertNotNull(resultado);
    assertEquals(2, resultado.size());
    // Verificar que o primeiro é o mais recente (pedido2)
    assertEquals(pedido2.getId(), resultado.get(0).getId());
    assertEquals(pedido2.getNumeroPedido(), resultado.get(0).getNumeroPedido());
    // Verificar que o segundo é o mais antigo (pedido1)
    assertEquals(pedido1.getId(), resultado.get(1).getId());
    assertEquals(pedido1.getNumeroPedido(), resultado.get(1).getNumeroPedido());
    // Verificar que a ordem está correta (mais recente primeiro)
    assertTrue(resultado.get(0).getDataCriacao()
        .isAfter(resultado.get(1).getDataCriacao()) ||
        resultado.get(0).getDataCriacao()
        .equals(resultado.get(1).getDataCriacao()));
    verify(pedidoRepository, times(1))
        .findAllByOrderByDataCriacaoDesc();
}
```

Este exemplo demonstra o padrão AAA (Arrange-Act-Assert) e a utilização de mocks para isolar a unidade de código testada.

[PLACEHOLDER: Adicionar mais exemplos de testes, se necessário]

---

## 7. RESULTADOS E ANÁLISE

Esta seção apresenta os resultados obtidos com a implementação dos testes, incluindo métricas de cobertura, análise dos resultados e discussão sobre a qualidade dos testes.

### 7.1 Cobertura Atual

Com base na matriz de cobertura apresentada na Seção 5.1, a cobertura geral atual do projeto é de aproximadamente **15%**. Esta cobertura é distribuída da seguinte forma:

#### 7.1.1 Cobertura por Camada

- **Services**: ~20% (apenas PedidoService com 100%)
- **Controllers**: ~30% (BackofficeController 70%, ClienteController 20%, LojaController 15%)
- **Models**: ~15% (apenas Pedido com 90%)

#### 7.1.2 Componentes com Cobertura Completa

- ✅ **PedidoService**: 100% de cobertura
- ✅ **Pedido (Model)**: 90% de cobertura

#### 7.1.3 Componentes com Cobertura Parcial

- ⚠️ **BackofficeController**: 70% de cobertura
- ⚠️ **ClienteController**: 20% de cobertura
- ⚠️ **LojaController**: 15% de cobertura

#### 7.1.4 Componentes Sem Cobertura

- ❌ **ClienteService**: 0% de cobertura
- ❌ **ProdutoService**: 0% de cobertura
- ❌ **UsuarioService**: 0% de cobertura
- ❌ **ViaCepService**: 0% de cobertura
- ❌ **LoginController**: 0% de cobertura
- ❌ **ProdutoController**: 0% de cobertura
- ❌ Todos os models exceto Pedido: 0% de cobertura

### 7.2 Análise dos Resultados

#### 7.2.1 Pontos Positivos

1. **Qualidade dos Testes Implementados**: Os testes do `PedidoService` demonstram boa qualidade, seguindo o padrão AAA e testando tanto casos de sucesso quanto casos de erro.

2. **Cobertura Completa de Componente Crítico**: O `PedidoService`, sendo um componente crítico do sistema, possui cobertura completa, garantindo confiabilidade nas operações de gestão de pedidos.

3. **Padrão Consistente**: Os testes implementados seguem um padrão consistente de nomenclatura e estrutura, facilitando a manutenção e compreensão.

#### 7.2.2 Pontos de Atenção

1. **Cobertura Geral Baixa**: A cobertura geral de 15% está significativamente abaixo da meta de 70%, indicando necessidade de implementação de mais testes.

2. **Falta de Testes em Componentes Críticos**: Componentes críticos como `ClienteService` e `UsuarioService` não possuem testes, representando um risco para a qualidade do sistema.

3. **Testes de Integração Limitados**: A maioria dos testes são unitários, com poucos testes de integração para validar o funcionamento conjunto dos componentes.

### 7.3 Métricas Detalhadas

[PLACEHOLDER: Adicionar tabela com métricas detalhadas de cobertura, se disponível:
- Cobertura de linhas por classe
- Cobertura de branches por classe
- Cobertura de métodos por classe
- Número de testes por componente
- Taxa de sucesso dos testes]

### 7.4 Análise Comparativa

[PLACEHOLDER: Adicionar análise comparativa, se aplicável:
- Comparação com outros projetos similares
- Benchmarks da indústria
- Evolução da cobertura ao longo do tempo]

### 7.5 Identificação de Defeitos

[PLACEHOLDER: Documentar defeitos encontrados durante os testes:
- Lista de bugs encontrados
- Severidade dos defeitos
- Status de correção]

### 7.6 Limitações dos Testes Atuais

1. **Cobertura Incompleta**: A maioria dos componentes não possui testes, limitando a confiança na qualidade do código.

2. **Falta de Testes de Integração**: Poucos testes validam a integração entre componentes, podendo deixar passar defeitos de integração.

3. **Testes de Performance Ausentes**: Não há testes de performance ou carga, limitando a compreensão do comportamento do sistema sob carga.

4. **Testes de Segurança Limitados**: Testes de segurança são limitados, podendo deixar vulnerabilidades não detectadas.

[PLACEHOLDER: Adicionar mais limitações, se identificadas]

### 7.7 Recomendações

Com base na análise dos resultados, as seguintes recomendações são propostas:

1. **Priorizar Testes de Componentes Críticos**: Implementar testes para `ClienteService` e `UsuarioService` como prioridade, devido à sua importância no sistema.

2. **Aumentar Cobertura Geral**: Trabalhar para atingir a meta de 70% de cobertura geral, seguindo a estratégia de prioridades definida no plano de testes.

3. **Implementar Testes de Integração**: Adicionar mais testes de integração para validar o funcionamento conjunto dos componentes.

4. **Automatizar Execução de Testes**: Configurar integração contínua para executar testes automaticamente em cada commit.

5. **Monitorar Cobertura**: Utilizar ferramentas como JaCoCo para monitorar a cobertura e garantir que não regrida.

[PLACEHOLDER: Adicionar mais recomendações, se necessário]

---

## 8. CONCLUSÃO

Este documento apresentou uma análise completa da estratégia de testes implementada no sistema Tadalafarma. Através da documentação dos planos de teste, testes implementados e resultados obtidos, foi possível identificar o estado atual da qualidade do código e as áreas que necessitam de atenção.

### 8.1 Síntese dos Resultados

O projeto Tadalafarma possui uma base sólida de testes, com o componente crítico `PedidoService` apresentando cobertura completa (100%). No entanto, a cobertura geral de aproximadamente 15% está significativamente abaixo da meta estabelecida de 70%, indicando necessidade de implementação de mais testes.

Os testes implementados demonstram boa qualidade, seguindo padrões estabelecidos (AAA, nomenclatura consistente) e utilizando frameworks adequados (JUnit 5, Mockito, Spring Boot Test). A estratégia de testes está bem definida, com planos detalhados para cada componente do sistema.

### 8.2 Contribuições do Trabalho

Este trabalho contribuiu para:
- Documentação completa da estratégia de testes do projeto
- Identificação de componentes críticos sem cobertura
- Definição de plano de ação para aumentar a cobertura
- Estabelecimento de padrões e boas práticas para testes

### 8.3 Limitações do Trabalho

Algumas limitações foram identificadas:
- Cobertura geral ainda baixa (15%)
- Falta de testes em componentes críticos
- Poucos testes de integração
- Ausência de testes de performance e segurança

### 8.4 Trabalhos Futuros

Como trabalhos futuros, sugere-se:
1. Implementação dos testes planejados seguindo a estratégia de prioridades
2. Aumento da cobertura geral para pelo menos 70%
3. Implementação de testes de integração mais abrangentes
4. Adição de testes de performance e segurança
5. Configuração de integração contínua para execução automática de testes
6. Implementação de testes end-to-end para fluxos críticos

### 8.5 Considerações Finais

A implementação de uma estratégia de testes robusta é fundamental para garantir a qualidade e confiabilidade do sistema Tadalafarma. Embora a cobertura atual seja baixa, o projeto possui uma base sólida e um plano claro para evolução. Com a implementação dos testes planejados, espera-se atingir a meta de 70% de cobertura e aumentar significativamente a confiança no sistema.

[PLACEHOLDER: Adicionar mais considerações finais, se necessário]

---

## REFERÊNCIAS

[PLACEHOLDER: Adicionar referências bibliográficas seguindo normas ABNT. Exemplos de referências a incluir:]

1. MYERS, G. J.; SANDLER, C.; BADGETT, T. **The Art of Software Testing**. 3. ed. Hoboken: John Wiley & Sons, 2011.

2. MARTIN, R. C. **Clean Code: A Handbook of Agile Software Craftsmanship**. Upper Saddle River: Prentice Hall, 2008.

3. FOWLER, M. **Refactoring: Improving the Design of Existing Code**. 2. ed. Boston: Addison-Wesley, 2018.

4. SPRING BOOT. **Spring Boot Reference Documentation**. Disponível em: https://docs.spring.io/spring-boot/. Acesso em: [DATA].

5. JUNIT. **JUnit 5 User Guide**. Disponível em: https://junit.org/junit5/docs/current/user-guide/. Acesso em: [DATA].

6. MOCKITO. **Mockito Documentation**. Disponível em: https://javadoc.io/doc/org.mockito/mockito-core/latest/org/mockito/Mockito.html. Acesso em: [DATA].

7. JACOCO. **JaCoCo Java Code Coverage Library**. Disponível em: https://www.jacoco.org/jacoco/. Acesso em: [DATA].

[PLACEHOLDER: Adicionar mais referências conforme necessário]

---

## ANEXOS

### Anexo A: Código de Exemplo - PedidoServiceTest Completo

[PLACEHOLDER: Incluir código completo do PedidoServiceTest.java]

### Anexo B: Relatório de Cobertura JaCoCo

[PLACEHOLDER: Incluir screenshots ou dados do relatório de cobertura, se disponível]

### Anexo C: Estrutura de Diretórios de Testes

```
src/test/java/com/tadalafarma/Tadalafarma/
├── controller/
│   ├── BackofficeControllerTest.java
│   ├── ClienteControllerTest.java
│   ├── LojaControllerTest.java
│   ├── LoginControllerTest.java
│   └── ProdutoControllerTest.java
├── model/
│   ├── ClienteTest.java
│   ├── EnderecoTest.java
│   ├── ItemPedidoTest.java
│   ├── PedidoTest.java
│   ├── ProdutoImagemTest.java
│   ├── ProdutoTest.java
│   └── UsuarioTest.java
├── service/
│   ├── ClienteServiceTest.java
│   ├── PedidoServiceTest.java
│   ├── ProdutoServiceTest.java
│   ├── UsuarioServiceTest.java
│   └── ViaCepServiceTest.java
└── TadalafarmaApplicationTests.java
```

### Anexo D: Configuração do JaCoCo no pom.xml

[PLACEHOLDER: Incluir configuração do plugin JaCoCo no pom.xml]

### Anexo E: Comandos para Execução de Testes

[PLACEHOLDER: Incluir lista de comandos Maven para execução de testes]

### Anexo F: Tabelas de Resultados Detalhados

[PLACEHOLDER: Incluir tabelas com resultados detalhados de execução de testes]

---

**FIM DO DOCUMENTO**

---

## NOTAS DE FORMATAÇÃO ABNT

Este documento foi criado em formato Markdown para facilitar a edição. Para gerar o documento final em formato ABNT (PDF/DOCX), recomenda-se:

1. Converter o Markdown para Word ou LaTeX
2. Aplicar formatação ABNT:
   - Fonte: Arial ou Times New Roman 12
   - Espaçamento: 1,5
   - Margens: 3cm (superior e esquerda), 2cm (inferior e direita)
   - Numeração de páginas: canto superior direito
   - Citações: padrão ABNT (autor-data)
3. Adicionar capa e folha de rosto conforme normas da instituição
4. Gerar sumário automático
5. Verificar referências bibliográficas

---

**Versão do Documento**: 1.0  
**Data de Criação**: [DATA]  
**Última Atualização**: [DATA]

