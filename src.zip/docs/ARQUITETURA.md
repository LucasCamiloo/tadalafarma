# Arquitetura do Sistema Tadalafarma

## Visão Geral

O Tadalafarma é uma aplicação web baseada em **Spring Boot** que segue a arquitetura em camadas (Layered Architecture), separando responsabilidades em diferentes níveis da aplicação.

## Padrão Arquitetural

### Arquitetura em Camadas

O sistema está organizado em quatro camadas principais:

```
┌─────────────────────────────────────────┐
│         CAMADA DE APRESENTAÇÃO          │
│         (Controllers + Views)            │
├─────────────────────────────────────────┤
│         CAMADA DE NEGÓCIO               │
│         (Services)                      │
├─────────────────────────────────────────┤
│         CAMADA DE PERSISTÊNCIA          │
│         (Repositories)                  │
├─────────────────────────────────────────┤
│         CAMADA DE DOMÍNIO               │
│         (Models/Entities)               │
└─────────────────────────────────────────┘
```

## Camadas do Sistema

### 1. Camada de Apresentação (Controllers)

**Responsabilidades:**
- Receber requisições HTTP
- Validar dados de entrada
- Chamar a camada de serviço
- Retornar respostas (views HTML ou JSON)
- Gerenciar sessões HTTP

**Componentes:**
- `BackofficeController` - Gestão do backoffice (pedidos, usuários)
- `ClienteController` - Gestão de clientes e checkout
- `LoginController` - Autenticação do backoffice
- `LojaController` - Interface pública da loja (produtos, carrinho)
- `ProdutoController` - Gestão de produtos (CRUD)

**Características:**
- Uso de `@Controller` para views HTML
- Validação de sessão manual (verificação de usuário logado)
- Redirecionamento para login quando não autenticado
- Controle de acesso baseado em grupos de usuários

### 2. Camada de Negócio (Services)

**Responsabilidades:**
- Implementar lógica de negócio
- Validações de dados
- Regras de negócio complexas
- Orquestração entre repositories
- Integrações externas

**Componentes:**
- `ClienteService` - Validações (CPF, email, nome), autenticação, CRUD de clientes
- `PedidoService` - Gestão de pedidos, validações de carrinho e pagamento
- `ProdutoService` - CRUD de produtos, gerenciamento de imagens
- `UsuarioService` - Autenticação e gestão de usuários do backoffice
- `ViaCepService` - Integração com API ViaCEP para busca de endereços

**Validações Implementadas:**
- CPF (algoritmo de validação com dígitos verificadores)
- Email (regex pattern)
- Nome (mínimo 2 palavras com 3+ letras cada)
- Data de nascimento (formato e não futura)
- Gênero (valores permitidos)
- Endereço (campos obrigatórios)
- Dados de cartão de crédito

### 3. Camada de Persistência (Repositories)

**Responsabilidades:**
- Abstração do acesso ao banco de dados
- Operações CRUD
- Consultas personalizadas
- Interface entre aplicação e MongoDB

**Componentes:**
- `ClienteRepository` - Operações com clientes
- `PedidoRepository` - Operações com pedidos
- `ProdutoRepository` - Operações com produtos
- `ProdutoImagemRepository` - Operações com imagens de produtos
- `UsuarioRepository` - Operações com usuários

**Características:**
- Uso de Spring Data MongoDB
- Métodos de consulta personalizados (ex: `findByEmail`, `findBySequencialId`)
- Consultas ordenadas (ex: `findAllByOrderByDataCriacaoDesc`)

### 4. Camada de Domínio (Models)

**Responsabilidades:**
- Representar entidades do negócio
- Encapsular dados e comportamentos
- Validações básicas
- Métodos auxiliares de negócio

**Entidades Principais:**

#### Cliente
- Dados pessoais (nome, CPF, email, data nascimento, gênero)
- Endereço de faturamento
- Lista de endereços de entrega
- Status (ativo/inativo)
- Métodos: `adicionarEnderecoEntrega()`, `getEnderecoPadraoEntrega()`

#### Produto
- Dados do produto (nome, descrição, preço, estoque, avaliação)
- Status (ativo/inativo)
- ID sequencial para exibição
- Timestamps (data criação, última alteração)

#### Pedido
- Número sequencial do pedido
- Referência ao cliente
- Lista de itens (ItemPedido)
- Endereço de entrega
- Forma de pagamento (BOLETO/CARTAO)
- Dados do cartão (classe interna DadosCartao)
- Valores (subtotal, frete, total)
- Status do pedido
- Métodos: `adicionarItem()`, `getStatusTexto()`

#### Usuario
- Dados do usuário do backoffice (nome, CPF, email)
- Grupo (ADMINISTRADOR/ESTOQUISTA)
- Status (ativo/inativo)
- ID sequencial para exibição

#### Endereco
- Dados completos do endereço (CEP, logradouro, número, complemento, bairro, cidade, UF)
- Flag de endereço padrão
- Método: `getEnderecoCompleto()` (formatação)

## Fluxo de Dados

### Fluxo Típico de Requisição

```
1. Cliente → Requisição HTTP
2. Controller → Recebe requisição
3. Controller → Valida sessão/autenticação
4. Controller → Chama Service
5. Service → Executa lógica de negócio
6. Service → Chama Repository (se necessário)
7. Repository → Acessa MongoDB
8. Repository → Retorna dados
9. Service → Processa e retorna resultado
10. Controller → Prepara modelo para view
11. Thymeleaf → Renderiza HTML
12. Controller → Retorna resposta HTTP
```

### Exemplo: Processo de Checkout

```
ClienteController.postCheckout()
  ↓
PedidoService.criarPedido()
  ↓
  ├─ ClienteRepository.findById() [validar cliente]
  ├─ ProdutoRepository.findBySequencialId() [cada item]
  ├─ Validar estoque e carrinho
  └─ PedidoRepository.save() [salvar pedido]
  ↓
Retornar resultado ao Controller
  ↓
Renderizar view de confirmação
```

## Autenticação e Autorização

### Estratégia de Autenticação

- **Método**: Autenticação baseada em sessão HTTP
- **Armazenamento**: Sessão do servidor (`HttpSession`)
- **Criptografia**: BCrypt para senhas

### Controle de Acesso

O sistema utiliza controle de acesso manual através de verificação de sessão nos controllers:

```java
private Usuario verificarSessao(HttpSession session) {
    return (Usuario) session.getAttribute("usuarioLogado");
}
```

### Grupos de Usuários

1. **ADMINISTRADOR**
   - Acesso completo ao sistema
   - Pode gerenciar produtos, usuários e pedidos
   - Acesso a todas as funcionalidades

2. **ESTOQUISTA**
   - Pode gerenciar pedidos (alterar status)
   - Pode alterar quantidade em estoque
   - Não pode criar/alterar produtos completamente

3. **CLIENTE** (não é um grupo, mas um tipo de usuário)
   - Acesso à loja e área do cliente
   - Não tem acesso ao backoffice

## Integração com MongoDB

### Estrutura de Dados

O MongoDB armazena documentos em coleções:

- `clientes` - Documentos de clientes
- `produtos` - Documentos de produtos
- `pedidos` - Documentos de pedidos
- `usuarios` - Documentos de usuários do backoffice
- `produto_imagens` - Documentos de imagens de produtos

### Índices

O sistema utiliza índices únicos para:
- Email (clientes e usuários)
- CPF (clientes e usuários)
- ID sequencial (produtos e usuários)
- Número do pedido (pedidos)

### Identificadores

- **ID MongoDB**: String gerada automaticamente (`@Id`)
- **ID Sequencial**: Long para exibição (ex: Produto #1, Usuário #1)

## Integração com ViaCEP API

### Serviço ViaCepService

- **Responsabilidade**: Buscar endereços por CEP
- **API Externa**: https://viacep.com.br/ws/{cep}/json/
- **Método**: REST API com RestTemplate
- **Tratamento**: Validação de CEP e tratamento de erros

### Fluxo de Integração

```
Cliente informa CEP
  ↓
ViaCepService.buscarEnderecoPorCep(cep)
  ↓
Requisição HTTP para API ViaCEP
  ↓
Processar resposta JSON
  ↓
Criar objeto Endereco
  ↓
Retornar para camada de serviço
```

## Gerenciamento de Imagens

### Estrutura de Armazenamento

- **Diretório Físico**: `src/main/resources/static/images/produtos/`
- **Banco de Dados**: Coleção `produto_imagens` com referências
- **Nomes de Arquivo**: UUID para garantir unicidade

### Fluxo de Upload

```
1. Controller recebe MultipartFile
2. ProdutoService.salvarImagem()
3. Gerar nome único (UUID)
4. Salvar arquivo físico no diretório
5. Salvar referência no MongoDB
6. Definir imagem principal (se solicitado)
```

## Gerenciamento de Sessão

### Dados Armazenados na Sessão

**Para Clientes:**
- `clienteLogado` - Objeto Cliente
- `carrinho` - Map<Long, Integer> (produtoId -> quantidade)
- `freteEscolhido` - BigDecimal
- `cepFreteAtual` - String
- `enderecoEscolhido` - Endereco (durante checkout)
- `formaPagamentoEscolhida` - String
- `dadosCartaoEscolhidos` - DadosCartao

**Para Usuários do Backoffice:**
- `usuarioLogado` - Objeto Usuario
- `grupoUsuario` - String (grupo do usuário)

## Estrutura de Pastas Explicada

```
src/main/java/com/tadalafarma/Tadalafarma/
├── config/
│   ├── DataInitializer.java      # Inicialização de dados padrão
│   └── SecurityConfig.java       # Configuração de segurança (Spring Security)
├── controller/
│   ├── BackofficeController.java # Controllers do backoffice
│   ├── ClienteController.java    # Controllers da área do cliente
│   ├── LoginController.java      # Login/logout do backoffice
│   ├── LojaController.java       # Loja pública
│   └── ProdutoController.java    # Gestão de produtos
├── model/
│   ├── Cliente.java              # Entidade Cliente
│   ├── Endereco.java             # Entidade Endereco
│   ├── ItemPedido.java           # Entidade ItemPedido
│   ├── Pedido.java               # Entidade Pedido
│   ├── Produto.java              # Entidade Produto
│   ├── ProdutoImagem.java        # Entidade ProdutoImagem
│   └── Usuario.java              # Entidade Usuario
├── repository/
│   ├── ClienteRepository.java    # Repository de Clientes
│   ├── PedidoRepository.java     # Repository de Pedidos
│   ├── ProdutoImagemRepository.java # Repository de Imagens
│   ├── ProdutoRepository.java    # Repository de Produtos
│   └── UsuarioRepository.java    # Repository de Usuários
└── service/
    ├── ClienteService.java       # Service de Clientes
    ├── PedidoService.java        # Service de Pedidos
    ├── ProdutoService.java       # Service de Produtos
    ├── UsuarioService.java       # Service de Usuários
    └── ViaCepService.java        # Service de integração ViaCEP
```

## Padrões de Design Utilizados

### Repository Pattern
- Abstração da camada de persistência
- Facilita testes e manutenção

### Service Layer Pattern
- Centralização da lógica de negócio
- Reutilização de código

### MVC (Model-View-Controller)
- Separação de responsabilidades
- Facilita manutenção e escalabilidade

### Session-Based Authentication
- Autenticação via sessão HTTP
- Simples e eficaz para aplicações web tradicionais

## Considerações de Segurança

### Implementações Atuais
- Criptografia de senhas com BCrypt
- Validação de CPF e email
- Controle de acesso manual via verificação de sessão
- Validação de entrada nos controllers

### Áreas de Atenção
- CSRF desabilitado (para desenvolvimento)
- Spring Security configurado de forma permissiva
- Validação manual de autenticação (pode ser melhorada)

## Escalabilidade e Performance

### Pontos Positivos
- Uso de índices no MongoDB
- Sessões server-side (pode migrar para Redis em escala)
- Separação clara de responsabilidades

### Possíveis Melhorias
- Cache para consultas frequentes
- Paginação implementada em produtos
- Upload de imagens para serviço externo (S3, Cloudinary)

## Dependências Principais

```xml
- spring-boot-starter-web       # Web MVC
- spring-boot-starter-data-mongodb # MongoDB
- spring-boot-starter-thymeleaf  # Template engine
- spring-boot-starter-security   # Segurança
- spring-boot-starter-test       # Testes
```

---

Esta arquitetura foi projetada para ser simples, mantível e escalável, seguindo as melhores práticas do Spring Boot e desenvolvimento web em Java.

