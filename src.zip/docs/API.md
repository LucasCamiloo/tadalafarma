# Documentação de API - Tadalafarma

## Visão Geral

Esta documentação descreve todos os endpoints da aplicação Tadalafarma, organizados por módulo e funcionalidade.

**URL Base**: `http://localhost:8081`

## Autenticação

O sistema utiliza autenticação baseada em sessão HTTP. O usuário deve fazer login para acessar áreas protegidas.

**Autenticação de Cliente**: Sessão com `clienteLogado`
**Autenticação de Backoffice**: Sessão com `usuarioLogado`

## Endpoints Públicos (Loja)

### Página Inicial

#### GET `/` ou `/loja`
Redireciona para a página principal da loja.

**Resposta**: Redirect para `/loja`

**View**: `loja/index.html`

---

### Catálogo de Produtos

#### GET `/loja`
Lista todos os produtos ativos disponíveis na loja.

**Parâmetros Query (opcionais):**
- `mensagem` (String) - Mensagem de sucesso/erro

**Resposta**: 
- Status: `200 OK`
- View: `loja/index.html`
- Model attributes:
  - `produtos` (List<Produto>)
  - `imagensPrincipais` (Map<Long, String>)
  - `totalItensCarrinho` (int)
  - `clienteLogado` (Cliente ou null)
  - `mensagem` (String)

---

### Detalhes do Produto

#### GET `/loja/produto/{id}`
Exibe detalhes de um produto específico.

**Parâmetros:**
- `id` (Long) - ID sequencial do produto

**Resposta**: 
- Status: `200 OK` (produto encontrado) ou `302 Redirect` para `/loja` (produto não encontrado)
- View: `loja/detalhe.html`
- Model attributes:
  - `produto` (Produto)
  - `imagens` (List<ProdutoImagem>)
  - `totalItensCarrinho` (int)

---

### Carrinho de Compras

#### GET `/loja/carrinho`
Exibe o carrinho de compras do cliente.

**Parâmetros Query (opcionais):**
- `erro` (String) - Mensagem de erro

**Resposta**: 
- Status: `200 OK`
- View: `loja/carrinho.html`
- Model attributes:
  - `itensCarrinho` (List<ItemCarrinho>)
  - `subtotal` (BigDecimal)
  - `freteAtual` (BigDecimal)
  - `total` (BigDecimal)
  - `opcoesFreteValores` (BigDecimal[])
  - `opcoesFreteNomes` (String[])
  - `clienteLogado` (Cliente ou null)
  - `cepFreteAtual` (String)

---

#### POST `/loja/carrinho/adicionar`
Adiciona um produto ao carrinho.

**Parâmetros:**
- `produtoId` (Long) - ID sequencial do produto
- `acao` (String, opcional, default: "carrinho") - "carrinho" ou "continuar"

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/loja/carrinho` ou `/loja` (se acao="continuar")

---

#### POST `/loja/carrinho/aumentar/{produtoId}`
Aumenta a quantidade de um produto no carrinho.

**Parâmetros:**
- `produtoId` (Long) - ID sequencial do produto

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/loja/carrinho`

---

#### POST `/loja/carrinho/diminuir/{produtoId}`
Diminui a quantidade de um produto no carrinho.

**Parâmetros:**
- `produtoId` (Long) - ID sequencial do produto

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/loja/carrinho`

---

#### POST `/loja/carrinho/remover/{produtoId}`
Remove um produto do carrinho.

**Parâmetros:**
- `produtoId` (Long) - ID sequencial do produto

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/loja/carrinho`

---

#### POST `/loja/carrinho/atualizar-frete`
Atualiza o valor do frete escolhido.

**Parâmetros:**
- `valorFrete` (BigDecimal) - Valor do frete

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/loja/carrinho`

---

#### POST `/loja/carrinho/calcular-frete-cep`
Calcula o frete baseado em um CEP informado.

**Parâmetros:**
- `cep` (String) - CEP (com ou sem formatação)

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/loja/carrinho` (CEP válido) ou `/loja/carrinho?erro=CEP inválido` (CEP inválido)

---

## Endpoints de Cliente

### Cadastro de Cliente (Público)

#### GET `/cadastro`
Exibe o formulário de cadastro de cliente.

**Resposta**: 
- Status: `200 OK`
- View: `cliente/cadastro.html`

---

#### POST `/cadastro`
Processa o cadastro de um novo cliente.

**Parâmetros:**
- `nome` (String) - Nome completo (mínimo 2 palavras, 3+ letras cada)
- `cpf` (String) - CPF (11 dígitos, válido)
- `email` (String) - Email válido e único
- `dataNascimento` (String) - Data no formato yyyy-MM-dd
- `genero` (String) - "masculino", "feminino", "outro" ou "não informado"
- `senha` (String) - Senha
- `confirmaSenha` (String) - Confirmação de senha
- `cep` (String) - CEP (8 dígitos)
- `logradouro` (String) - Logradouro
- `numero` (String) - Número
- `complemento` (String, opcional) - Complemento
- `bairro` (String) - Bairro
- `cidade` (String) - Cidade
- `uf` (String) - UF (2 caracteres)

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/login?sucesso=Cliente cadastrado com sucesso` (sucesso) ou mantém na view com erro (falha)

**Validações:**
- CPF válido e único
- Email válido e único
- Nome com 2+ palavras, 3+ letras cada
- Data de nascimento válida (não futura)
- Senhas conferem
- CEP válido e encontrado na API ViaCEP

---

### Login de Cliente

#### GET `/login`
Exibe o formulário de login do cliente.

**Parâmetros Query (opcionais):**
- `sucesso` (String) - Mensagem de sucesso
- `erro` (String) - Mensagem de erro

**Resposta**: 
- Status: `200 OK`
- View: `cliente/login.html`

---

#### POST `/login`
Processa o login do cliente.

**Parâmetros:**
- `email` (String) - Email do cliente
- `senha` (String) - Senha do cliente

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/cliente/perfil` (sucesso) ou `/login` com erro (falha)

**Sessão**: Define `clienteLogado` na sessão

---

#### GET `/logout`
Realiza logout do cliente.

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/loja?mensagem=Sessão encerrada com sucesso`

**Sessão**: Remove `clienteLogado` da sessão

---

### Perfil do Cliente (Autenticado)

#### GET `/cliente/perfil`
Exibe o perfil do cliente logado.

**Autenticação**: Requerida (cliente logado)

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/login` (não autenticado)
- View: `cliente/perfil.html`
- Model attributes:
  - `cliente` (Cliente)

---

#### GET `/cliente/alterar-dados`
Exibe formulário para alterar dados pessoais.

**Autenticação**: Requerida

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/login`
- View: `cliente/alterar-dados.html`

---

#### POST `/cliente/alterar-dados`
Processa alteração de dados pessoais.

**Autenticação**: Requerida

**Parâmetros:**
- `nome` (String) - Novo nome
- `dataNascimento` (String) - Nova data de nascimento
- `genero` (String) - Novo gênero

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/cliente/perfil?sucesso=Dados alterados com sucesso` ou mantém na view com erro

---

#### GET `/cliente/alterar-senha`
Exibe formulário para alterar senha.

**Autenticação**: Requerida

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/login`
- View: `cliente/alterar-senha.html`

---

#### POST `/cliente/alterar-senha`
Processa alteração de senha.

**Autenticação**: Requerida

**Parâmetros:**
- `novaSenha` (String) - Nova senha
- `confirmaSenha` (String) - Confirmação de senha

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/cliente/perfil?sucesso=Senha alterada com sucesso` ou mantém na view com erro

---

### Endereços de Entrega (Autenticado)

#### GET `/cliente/enderecos`
Lista endereços de entrega do cliente.

**Autenticação**: Requerida

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/login`
- View: `cliente/enderecos.html`
- Model attributes:
  - `cliente` (Cliente)

---

#### GET `/cliente/adicionar-endereco`
Exibe formulário para adicionar endereço.

**Autenticação**: Requerida

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/login`
- View: `cliente/adicionar-endereco.html`

---

#### POST `/cliente/adicionar-endereco`
Processa adição de novo endereço.

**Autenticação**: Requerida

**Parâmetros:**
- `cep` (String) - CEP
- `logradouro` (String) - Logradouro
- `numero` (String) - Número
- `complemento` (String, opcional) - Complemento
- `bairro` (String) - Bairro
- `cidade` (String) - Cidade
- `uf` (String) - UF
- `definirComoPadrao` (boolean, opcional) - Se deve definir como padrão

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/cliente/enderecos?sucesso=Endereço adicionado com sucesso` ou mantém na view com erro

---

#### POST `/cliente/alterar-endereco-padrao`
Altera o endereço padrão de entrega.

**Autenticação**: Requerida

**Parâmetros:**
- `enderecoId` (String) - ID do endereço

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/cliente/enderecos?sucesso=Endereço padrão alterado com sucesso&freteAtualizado=true`

---

### Pedidos do Cliente (Autenticado)

#### GET `/cliente/meus-pedidos`
Lista todos os pedidos do cliente logado.

**Autenticação**: Requerida

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/login`
- View: `cliente/meus-pedidos.html`
- Model attributes:
  - `pedidos` (List<Pedido>)
  - `cliente` (Cliente)

---

#### GET `/cliente/pedido/{numeroPedido}`
Exibe detalhes de um pedido específico.

**Autenticação**: Requerida

**Parâmetros:**
- `numeroPedido` (Long) - Número do pedido

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/cliente/meus-pedidos?erro=Pedido não encontrado`
- View: `cliente/detalhes-pedido.html`
- Model attributes:
  - `pedido` (Pedido)
  - `cliente` (Cliente)

**Validação**: Verifica se o pedido pertence ao cliente logado

---

### Checkout (Autenticado)

#### POST `/checkout/iniciar`
Inicia o processo de checkout.

**Autenticação**: Requerida (redireciona para login se não autenticado)

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/checkout/endereco` (cliente logado com carrinho) ou `/login` (não logado) ou `/loja/carrinho?erro=Carrinho vazio` (carrinho vazio)

---

#### GET `/checkout/endereco`
Exibe página para escolher endereço de entrega.

**Autenticação**: Requerida

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/login`
- View: `checkout/escolher-endereco.html`
- Model attributes:
  - `cliente` (Cliente)
  - `enderecos` (List<Endereco>)

---

#### POST `/checkout/endereco`
Processa escolha de endereço de entrega.

**Autenticação**: Requerida

**Parâmetros:**
- `enderecoId` (String) - ID do endereço escolhido

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/checkout/pagamento` (sucesso) ou mantém na view com erro

**Sessão**: Define `enderecoEscolhido`

---

#### GET `/checkout/adicionar-endereco`
Exibe formulário para adicionar endereço durante checkout.

**Autenticação**: Requerida

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/login`
- View: `checkout/adicionar-endereco.html`

---

#### POST `/checkout/adicionar-endereco`
Processa adição de endereço durante checkout.

**Autenticação**: Requerida

**Parâmetros:** (mesmos do `/cliente/adicionar-endereco`)

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/checkout/pagamento` (sucesso) ou mantém na view com erro

---

#### GET `/checkout/pagamento`
Exibe página para escolher forma de pagamento.

**Autenticação**: Requerida

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/login` ou `/checkout/endereco` (sem endereço)
- View: `checkout/escolher-pagamento.html`
- Model attributes:
  - `cliente` (Cliente)

---

#### POST `/checkout/pagamento`
Processa escolha de forma de pagamento.

**Autenticação**: Requerida

**Parâmetros:**
- `formaPagamento` (String) - "BOLETO" ou "CARTAO"
- `numeroCartao` (String, opcional) - Se formaPagamento="CARTAO"
- `codigoVerificador` (String, opcional) - Se formaPagamento="CARTAO"
- `nomeCompleto` (String, opcional) - Se formaPagamento="CARTAO"
- `dataVencimento` (String, opcional) - Se formaPagamento="CARTAO" (formato MM/AA)
- `quantidadeParcelas` (Integer, opcional) - Se formaPagamento="CARTAO" (1-12)

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/checkout/resumo` (sucesso) ou mantém na view com erro

**Sessão**: Define `formaPagamentoEscolhida` e `dadosCartaoEscolhidos`

---

#### GET `/checkout/resumo`
Exibe resumo do pedido antes da confirmação.

**Autenticação**: Requerida

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` (se faltar dados)
- View: `checkout/resumo.html`
- Model attributes:
  - `itens` (List<ItemCarrinho>)
  - `subtotal` (BigDecimal)
  - `frete` (BigDecimal)
  - `total` (BigDecimal)
  - `endereco` (Endereco)
  - `formaPagamento` (String)
  - `dadosCartao` (DadosCartao ou null)
  - `cliente` (Cliente)

---

#### POST `/checkout/finalizar`
Finaliza o pedido e cria o registro no banco de dados.

**Autenticação**: Requerida

**Resposta**: 
- Status: `302 Redirect` ou view de erro
- Redirect: View `checkout/pedido-confirmado.html` (sucesso)
- Model attributes:
  - `numeroPedido` (Long)
  - `total` (BigDecimal)
  - `sucesso` (String)

**Sessão**: Limpa carrinho e dados de checkout após sucesso

---

#### POST `/checkout/voltar`
Volta para a página de pagamento.

**Autenticação**: Requerida

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/checkout/pagamento`

---

## Endpoints de Backoffice

### Login de Backoffice (Público)

#### GET `/backoffice/login`
Exibe formulário de login do backoffice.

**Resposta**: 
- Status: `200 OK`
- View: `login.html`

---

#### POST `/backoffice/login`
Processa login do backoffice.

**Parâmetros:**
- `email` (String) - Email do usuário
- `senha` (String) - Senha do usuário

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/backoffice` (sucesso) ou mantém na view com erro

**Sessão**: Define `usuarioLogado` e `grupoUsuario`

---

#### GET `/backoffice/logout`
Realiza logout do backoffice.

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/backoffice/login`

**Sessão**: Invalida toda a sessão

---

### Dashboard do Backoffice (Autenticado)

#### GET `/backoffice`
Exibe dashboard do backoffice.

**Autenticação**: Requerida

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/backoffice/login`
- View: `backoffice.html`
- Model attributes:
  - `usuario` (Usuario)
  - `isAdmin` (boolean)

---

### Gestão de Pedidos (Autenticado)

#### GET `/pedidos`
Lista todos os pedidos (ordenados por data decrescente).

**Autenticação**: Requerida

**Parâmetros Query (opcionais):**
- `sucesso` (String) - Mensagem de sucesso
- `erro` (String) - Mensagem de erro

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/backoffice/login`
- View: `pedidos/listar.html`
- Model attributes:
  - `pedidos` (List<Pedido>)
  - `usuario` (Usuario)

---

#### GET `/pedidos/{id}/editar`
Exibe formulário para editar status do pedido.

**Autenticação**: Requerida

**Parâmetros:**
- `id` (String) - ID do pedido

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/pedidos?erro=Pedido não encontrado`
- View: `pedidos/editar.html`
- Model attributes:
  - `pedido` (Pedido)
  - `usuario` (Usuario)

---

#### POST `/pedidos/{id}/editar`
Processa alteração de status do pedido.

**Autenticação**: Requerida

**Parâmetros:**
- `id` (String) - ID do pedido
- `status` (String) - Novo status do pedido

**Status válidos:**
- `AGUARDANDO_PAGAMENTO`
- `PAGAMENTO_REJEITADO`
- `PAGAMENTO_COM_SUCESSO`
- `AGUARDANDO_RETIRADA`
- `EM_TRANSITO`
- `ENTREGUE`

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/pedidos?sucesso=Status atualizado com sucesso` ou mantém na view com erro

---

### Gestão de Produtos (Autenticado)

#### GET `/produtos`
Lista produtos com paginação e busca.

**Autenticação**: Requerida

**Parâmetros Query:**
- `busca` (String, opcional) - Termo de busca
- `pagina` (int, opcional, default: 0) - Número da página

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/login`
- View: `produtos/listar.html`
- Model attributes:
  - `produtos` (List<Produto>)
  - `totalPages` (int)
  - `currentPage` (int)
  - `busca` (String)
  - `isAdmin` (boolean)
  - `isEstoquista` (boolean)

---

#### GET `/produtos/cadastrar`
Exibe formulário para cadastrar produto.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Resposta**: 
- Status: `200 OK` ou `302 Redirect` para `/produtos?erro=Acesso negado`
- View: `produtos/cadastrar.html`

---

#### POST `/produtos/cadastrar`
Processa cadastro de novo produto.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `nome` (String) - Nome do produto (máx. 200 caracteres)
- `avaliacao` (BigDecimal) - Avaliação (1-5)
- `descricaoDetalhada` (String) - Descrição (máx. 2000 caracteres)
- `preco` (BigDecimal) - Preço (maior que zero)
- `quantidadeEstoque` (Integer) - Quantidade em estoque (≥0)
- `imagens` (List<MultipartFile>, opcional) - Imagens do produto
- `imagemPrincipal` (List<Boolean>, opcional) - Se cada imagem é principal

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/produtos?sucesso=Produto cadastrado com sucesso` ou mantém na view com erro

---

#### GET `/produtos/{id}/alterar`
Exibe formulário para alterar produto.

**Autenticação**: Requerida

**Parâmetros:**
- `id` (Long) - ID sequencial do produto

**Resposta**: 
- Status: `200 OK` ou `302 Redirect`
- View: `produtos/alterar.html`
- Model attributes:
  - `produto` (Produto)
  - `imagens` (List<ProdutoImagem>)
  - `isAdmin` (boolean)
  - `isEstoquista` (boolean)

**Permissão**: ADMINISTRADOR pode alterar tudo; ESTOQUISTA pode alterar apenas quantidade

---

#### POST `/produtos/{id}/alterar`
Processa alteração de produto.

**Autenticação**: Requerida

**Parâmetros:**
- `id` (Long) - ID sequencial do produto
- `nome` (String, opcional) - Novo nome
- `avaliacao` (BigDecimal, opcional) - Nova avaliação
- `descricaoDetalhada` (String, opcional) - Nova descrição
- `preco` (BigDecimal, opcional) - Novo preço
- `quantidadeEstoque` (Integer) - Nova quantidade
- `novasImagens` (List<MultipartFile>, opcional) - Novas imagens
- `novaImagemPrincipal` (List<Boolean>, opcional) - Se novas imagens são principais
- `imagensParaDeletar` (List<String>, opcional) - IDs de imagens para deletar

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/produtos?sucesso=Produto alterado com sucesso` ou mantém na view com erro

---

#### GET `/produtos/{id}/visualizar`
Visualiza produto como será exibido na loja.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `id` (Long) - ID sequencial do produto

**Resposta**: 
- Status: `200 OK` ou `302 Redirect`
- View: `produtos/visualizar.html`
- Model attributes:
  - `produto` (Produto)
  - `imagens` (List<ProdutoImagem>)

---

#### POST `/produtos/{id}/status`
Altera status do produto (ativo/inativo).

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `id` (Long) - ID sequencial do produto

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/produtos?sucesso=Status do produto alterado com sucesso`

---

#### POST `/produtos/imagem/{imagemId}/deletar`
Deleta uma imagem de produto.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `imagemId` (String) - ID da imagem

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/produtos?sucesso=Imagem deletada com sucesso`

---

#### POST `/produtos/{produtoId}/imagem/{imagemId}/principal`
Define uma imagem como principal do produto.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `produtoId` (Long) - ID sequencial do produto
- `imagemId` (String) - ID da imagem

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/produtos/{produtoId}/alterar?sucesso=Imagem definida como principal com sucesso`

---

### Gestão de Usuários (Autenticado - Admin)

#### GET `/usuarios`
Lista todos os usuários do backoffice.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Resposta**: 
- Status: `200 OK` ou `302 Redirect`
- View: `usuarios/listar.html`
- Model attributes:
  - `usuarios` (List<Usuario>)

---

#### POST `/usuarios/acao`
Processa ação de seleção de usuário ou criação.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `acao` (String) - "0" (voltar), "I" (cadastrar) ou ID sequencial do usuário

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/backoffice` (acao="0"), `/usuarios/cadastrar` (acao="I") ou `/usuarios/{id}/opcoes` (ID)

---

#### GET `/usuarios/cadastrar`
Exibe formulário para cadastrar usuário.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Resposta**: 
- Status: `200 OK` ou `302 Redirect`
- View: `usuarios/cadastrar.html`

---

#### POST `/usuarios/cadastrar`
Processa cadastro de novo usuário.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `nome` (String) - Nome do usuário
- `cpf` (String) - CPF válido e único
- `email` (String) - Email válido e único
- `grupo` (String) - "ADMINISTRADOR" ou "ESTOQUISTA"
- `senha` (String) - Senha
- `confirmaSenha` (String) - Confirmação de senha

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/usuarios?sucesso=Usuário cadastrado com sucesso` ou mantém na view com erro

---

#### GET `/usuarios/{id}/opcoes`
Exibe opções para um usuário específico.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `id` (Long) - ID sequencial do usuário

**Resposta**: 
- Status: `200 OK` ou `302 Redirect`
- View: `usuarios/opcoes.html`
- Model attributes:
  - `usuario` (Usuario)

---

#### POST `/usuarios/{id}/opcoes`
Processa ação selecionada para o usuário.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `id` (Long) - ID sequencial do usuário
- `opcao` (int) - 1 (alterar), 2 (senha), 3 (status), 4 (voltar)

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/usuarios/{id}/alterar`, `/usuarios/{id}/senha`, `/usuarios/{id}/status` ou `/usuarios`

---

#### GET `/usuarios/{id}/alterar`
Exibe formulário para alterar usuário.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `id` (Long) - ID sequencial do usuário

**Resposta**: 
- Status: `200 OK` ou `302 Redirect`
- View: `usuarios/alterar.html`
- Model attributes:
  - `usuario` (Usuario)

---

#### POST `/usuarios/{id}/alterar`
Processa alteração de usuário.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `id` (Long) - ID sequencial do usuário
- `nome` (String) - Novo nome
- `cpf` (String) - Novo CPF
- `grupo` (String) - Novo grupo
- `salvar` (String) - "S" (salvar) ou "N" (cancelar)

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/usuarios/{id}/opcoes?sucesso=Usuário alterado com sucesso` ou mantém na view com erro

---

#### GET `/usuarios/{id}/senha`
Exibe formulário para alterar senha do usuário.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `id` (Long) - ID sequencial do usuário

**Resposta**: 
- Status: `200 OK` ou `302 Redirect`
- View: `usuarios/senha.html`
- Model attributes:
  - `usuario` (Usuario)

---

#### POST `/usuarios/{id}/senha`
Processa alteração de senha do usuário.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `id` (Long) - ID sequencial do usuário
- `novaSenha` (String) - Nova senha
- `confirmaSenha` (String) - Confirmação de senha
- `salvar` (String) - "S" (salvar) ou "N" (cancelar)

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/usuarios/{id}/opcoes?sucesso=Senha alterada com sucesso` ou mantém na view com erro

---

#### GET `/usuarios/{id}/status`
Exibe página para alterar status do usuário.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `id` (Long) - ID sequencial do usuário

**Resposta**: 
- Status: `200 OK` ou `302 Redirect`
- View: `usuarios/status.html`
- Model attributes:
  - `usuario` (Usuario)
  - `novoStatus` (boolean)
  - `acao` (String) - "Ativar" ou "Desativar"

---

#### POST `/usuarios/{id}/status`
Processa alteração de status do usuário.

**Autenticação**: Requerida
**Permissão**: Apenas ADMINISTRADOR

**Parâmetros:**
- `id` (Long) - ID sequencial do usuário
- `salvar` (String) - "S" (salvar) ou "N" (cancelar)

**Resposta**: 
- Status: `302 Redirect`
- Redirect: `/usuarios/{id}/opcoes?sucesso=Usuário ativado/desativado com sucesso`

---

## API REST (JSON)

### Buscar CEP

#### GET `/api/cep/{cep}`
Busca endereço por CEP através da API ViaCEP.

**Parâmetros:**
- `cep` (String) - CEP (8 dígitos, com ou sem formatação)

**Resposta**: 
- Status: `200 OK`
- Content-Type: `application/json`
- Body: Objeto `Endereco` (JSON) ou `null` se CEP inválido

**Exemplo de Resposta:**
```json
{
  "id": "uuid",
  "cep": "01310100",
  "logradouro": "Avenida Paulista",
  "bairro": "Bela Vista",
  "cidade": "São Paulo",
  "uf": "SP",
  "numero": null,
  "complemento": null,
  "padrao": false
}
```

---

## Códigos de Status HTTP

- `200 OK` - Requisição bem-sucedida
- `302 Found` - Redirecionamento
- `400 Bad Request` - Requisição inválida (tratado internamente com redirect)
- `404 Not Found` - Recurso não encontrado (tratado internamente com redirect)

## Mensagens de Erro Comuns

- `Email ou senha inválidos, ou usuário inativo` - Credenciais inválidas
- `Acesso negado` - Usuário não tem permissão
- `Cliente não encontrado` - Cliente não existe no banco
- `Pedido não encontrado` - Pedido não existe ou não pertence ao cliente
- `Produto não encontrado` - Produto não existe
- `CEP inválido` - CEP inválido ou não encontrado
- `Carrinho vazio` - Tentativa de checkout com carrinho vazio

---

**Nota**: Todos os endpoints que requerem autenticação verificam a sessão antes de processar. Se não autenticado, o usuário é redirecionado para a página de login apropriada.

