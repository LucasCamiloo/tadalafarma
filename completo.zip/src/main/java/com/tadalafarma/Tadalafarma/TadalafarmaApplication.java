package com.tadalafarma.Tadalafarma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TadalafarmaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TadalafarmaApplication.class, args);
	}

}
